
























#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<R.h>
#include<Rmath.h>

void yiumjq3npnm1or(double *objzgdk0, double *lfu2qhid);
void yiumjq3npnm1ow(double objzgdk0[], double lfu2qhid[], int *f8yswcat);
void yiumjq3nn2howibc2a(double *objzgdk0, double *i9mwnvqt, double *lfu2qhid);
void yiumjq3nbewf1pzv9(double *objzgdk0, double *lfu2qhid);
void yiumjq3ng2vwexyk9(double *objzgdk0, double *lfu2qhid);
void yiumjq3npkc4ejib(double w8znmyce[], double zshtfg8c[], double m0ibglfx[],
                  int *ftnjamu2, int *wy1vqfzu, int *br5ovgcj, int *xlpjcg3s,
                  int *vtsou9pz, int *hj3ftvzu, int *qfx3vhct, int *unhycz0e,
                  double vm4xjosb[]);
void yiumjq3nnipyajc1(double m0ibglfx[], double t8hwvalr[], int *ftnjamu2, int *wy1vqfzu,
                   int *afpc0kns, int *qfx3vhct, int *hj3ftvzu);
void yiumjq3nshjlwft5(int *qfx3vhct, double tlgduey8[], double ufgqj9ck[],
                  double t8hwvalr[], int *ftnjamu2, int *wy1vqfzu, int *afpc0kns,
                  int *kvowz9ht, double m0ibglfx[], double *jxacz5qu, int *hj3ftvzu,
                  double *dn3iasxug, double *vsoihn1r, int *dqk5muto);
void yiumjq3nflncwkfq76(double lncwkfq7[], double w8znmyce[], int *ftnjamu2,
                   int *br5ovgcj, int *xwdf5ltg, int *qfx3vhct);
void yiumjq3nflncwkfq71(double lncwkfq7[], double w8znmyce[], int *ftnjamu2,
                   int *xwdf5ltg, int *qfx3vhct, double vm4xjosb[], int *br5ovgcj,
                   int *xlpjcg3s,
                   double kifxa0he[], int *yru9olks, int *unhycz0e);
void yiumjq3nflncwkfq72(double lncwkfq7[], double w8znmyce[], int *ftnjamu2, int *wy1vqfzu,
                   int *br5ovgcj, int *xwdf5ltg, int *qfx3vhct, int *afpc0kns,
                   int *fmzq7aob, int *eu3oxvyb,
                   int *unhycz0e, double vm4xjosb[]);
void yiumjq3nietam6(double tlgduey8[], double m0ibglfx[], double y7sdgtqi[],
                  int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *qfx3vhct,
                  int *hj3ftvzu, double ufgqj9ck[], int *wr0lbopv);
void yiumjq3ndlgpwe0c(double tlgduey8[], double ufgqj9ck[], double m0ibglfx[],
        double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
        double wpuarq2m[], double *rsynp1go, double *dn3iasxug, double *uaf2xgqy,
        int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
        int *hj3ftvzu, int *qfx3vhct, int *zjkrtol8, int *unhycz0e, double vm4xjosb[]);
void cqo_2(double lncwkfq7[], double tlgduey8[], double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[], double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[],
                double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                int *zjkrtol8, int xui7hqwl[],
                double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[]);
void cqo_1(double lncwkfq7[], double tlgduey8[], double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[], double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[],
                double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                int *zjkrtol8, int xui7hqwl[],
                double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[]);
void vcao6(double lncwkfq7[], double tlgduey8[], double ufgqj9ck[],
                 double m0ibglfx[], double t8hwvalr[], double ghz9vuba[],
                 double rbne6ouj[], double wpuarq2m[],
                 double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                 int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                 int *zjkrtol8, int xui7hqwl[],
                 double *tlq9wpes, double zshtfg8c[],
                 double y7sdgtqi[], int psdvgce3[], int *qfozcl5b,
                 double hdnw2fts[], double lamvec[], double wbkq9zyi[],
                 int ezlgm2up[], int lqsahu0r[], int which[],
                 double kispwgx3[],
                 double mbvnaor6[],
                 double hjm2ktyr[],
                 int jnxpuym2[], int hnpt1zym[],
                 int iz2nbfjc[],
                 double ifys6woa[], double rpyis2kc[], double gkdx5jals[],
                 int nbzjkpi3[], int lindex[],
                 int acpios9q[], int jwbkl9fp[]);
void dcqo1(double lncwkfq7[], double tlgduey8[], double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[], double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[], double vc6hatuj[],
                double fasrkub3[], int ges1xpkr[], int *ftnjamu2, int *wy1vqfzu,
                int *afpc0kns, int *br5ovgcj, int *npjlv3mr, int *zjkrtol8,
                int xui7hqwl[], double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[],
                double atujnxb8[],
                double k7hulceq[], int *eoviz2fb,
                double kpzavbj3mat[], double *ydcnh9xl);
void vdcao6(double lncwkfq7[], double tlgduey8[], double ufgqj9ck[],
                  double m0ibglfx[], double t8hwvalr[], double ghz9vuba[],
                  double rbne6ouj[], double wpuarq2m[],
                  double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                  int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                  int *zjkrtol8, int xui7hqwl[],
                  double *tlq9wpes, double zshtfg8c[],
                  double y7sdgtqi[],
                  double atujnxb8[],
                  double k7hulceq[],
                  int *eoviz2fb, double kpzavbj3mat[],
                  double ajul8wkv[],
                  int psdvgce3[], int *qfozcl5b,
                  double hdnw2fts[], double lamvec[], double wbkq9zyi[],
                  int ezlgm2up[], int lqsahu0r[], int which[],
                  double kispwgx3[],
                  double mbvnaor6[],
                  double hjm2ktyr[],
                  int jnxpuym2[], int hnpt1zym[],
                  int iz2nbfjc[],
                  double ifys6woa[],
                  double rpyis2kc[], double gkdx5jals[],
                  int nbzjkpi3[], int lindex[],
                  int acpios9q[], int jwbkl9fp[]);

double fvlmz9iyC_tldz5ion(double xx);
void fvlmz9iyC_qpsedg8x(int tgiyxdw1[], int dufozmt7[], int *wy1vqfzu);
void fvlmz9iyC_enbin9(double lfu2qhid[], double hdqsx7bk[], double nm0eljqk[],
                   double *n2kersmx, int *f8yswcat, int *dvhw1ulq, int *zy1mchbf,
                   double *ux3nadiw, double *rsynp1go, int *sguwj9ty);

void Yee_vbfa(int psdvgce3[], double *fjcasv7g, double he7mqnvy[], double tlgduey8[],
       double rbne6ouj[], double hdnw2fts[], double lamvec[], double wbkq9zyi[],
       int ezlgm2up[], int lqsahu0r[], int which[],
       double kispwgx3[], double m0ibglfx[],
       double zshtfg8c[], double ui8ysltq[],
       double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
       double wpuarq2m[], double hjm2ktyr[],
       int ulm3dvzg[], int hnpt1zym[], int iz2nbfjc[],
       double ifys6woa[],
       double rpyis2kc[], double gkdx5jals[],
       int nbzjkpi3[], int lindex[],  // 20130525; lindex added
       int acpios9q[], int jwbkl9fp[]);




void F77_NAME(vqrdca)(double*, int*, int*, int*, double*, int*,
                      double*, int*, double*);
void F77_NAME(vdqrsl)(double*, int*, int*, int*, double*, double*, double*,
                      double*, double*, double*, double*, int*, int*);

void tyee_C_vdgam1(double*, double*, int*);
void tyee_C_vtgam1(double*, double*, int*);


void yiumjq3nn2howibc2a(double *objzgdk0, double *i9mwnvqt, double *lfu2qhid) {

  double pq0hfucn, xd4mybgj;


  if (1.0e0 - *objzgdk0 >= 1.0e0) {
    *lfu2qhid = -8.12589e0 / (3.0 * sqrt(*i9mwnvqt));
  } else
  if (1.0e0 - *objzgdk0 <= 0.0e0) {
    *lfu2qhid =  8.12589e0 / (3.0 * sqrt(*i9mwnvqt));
  } else {
    pq0hfucn = 1.0e0 - *objzgdk0;
    yiumjq3npnm1or(&pq0hfucn, &xd4mybgj);
    xd4mybgj  /=  3.0e0 * sqrt(*i9mwnvqt);
    *lfu2qhid = -3.0e0 * log(1.0e0 + xd4mybgj);
  }
}


void yiumjq3nbewf1pzv9(double *objzgdk0, double *lfu2qhid) {


  if (*objzgdk0 <= 2.0e-200) {
    *lfu2qhid = -460.0e0;
  } else
  if (*objzgdk0 <= 1.0e-14) {
    *lfu2qhid = log( *objzgdk0 );
  } else
  if (1.0e0 - *objzgdk0 <= 0.0e0) {
    *lfu2qhid = 3.542106e0;
  } else {
    *lfu2qhid = log(-log(1.0e0 - *objzgdk0));
  }
}


void yiumjq3ng2vwexyk9(double *objzgdk0, double *lfu2qhid) {

  if (*objzgdk0 <= 2.0e-200) {
    *lfu2qhid = -460.0e0;
  } else
  if (*objzgdk0 <= 1.0e-14) {
    *lfu2qhid = log( *objzgdk0 );
  } else
  if (1.0e0 - *objzgdk0 <= 0.0e0) {
    *lfu2qhid =  34.53958e0;
  } else {
    *lfu2qhid = log(*objzgdk0 / (1.0e0 - *objzgdk0));
  }
}


void yiumjq3npkc4ejib(double w8znmyce[], double zshtfg8c[], double m0ibglfx[],
                  int *ftnjamu2, int *wy1vqfzu, int *br5ovgcj, int *xlpjcg3s,
                  int *vtsou9pz, int *hj3ftvzu, int *qfx3vhct, int *unhycz0e,
                  double vm4xjosb[]) {




  int    ayfnwr1v, yq6lorbx, gp1jxzuh, sedf7mxb;
  double *fpdlcqk9zshtfg8c, *fpdlcqk9w8znmyce, *fpdlcqk9f9piukdx,
         *fpdlcqk9m0ibglfx, *fpdlcqk9vm4xjosb;

  if (*vtsou9pz == 1) {
    if (*qfx3vhct == 3 || *qfx3vhct == 5) {
      sedf7mxb = 2 * *hj3ftvzu - 1;

      if (*br5ovgcj != 2 * *ftnjamu2)  //Rprinf
        Rprintf("Error: *br5ovgcj != 2 * *ftnjamu2 in C_pkc4ejib\n");
      fpdlcqk9m0ibglfx = m0ibglfx + sedf7mxb-1;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx  = 0.0;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }

      fpdlcqk9zshtfg8c = zshtfg8c;
      for (gp1jxzuh = 1; gp1jxzuh <= *xlpjcg3s; gp1jxzuh++) {
        fpdlcqk9w8znmyce = w8znmyce + 0 + (gp1jxzuh-1) * *br5ovgcj;
        fpdlcqk9m0ibglfx = m0ibglfx + sedf7mxb-1;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9m0ibglfx += *fpdlcqk9w8znmyce++ * *fpdlcqk9zshtfg8c;
           fpdlcqk9w8znmyce++;
           fpdlcqk9m0ibglfx += *wy1vqfzu;
        }
        fpdlcqk9zshtfg8c++;
      }

      sedf7mxb = 2 * *hj3ftvzu;

      fpdlcqk9m0ibglfx = m0ibglfx + sedf7mxb-1;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx  = 0.0;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }

      fpdlcqk9zshtfg8c = zshtfg8c;
      for (gp1jxzuh = 1; gp1jxzuh <= *xlpjcg3s; gp1jxzuh++) {
        fpdlcqk9w8znmyce = w8znmyce + 1 + (gp1jxzuh-1) * *br5ovgcj;
        fpdlcqk9m0ibglfx = m0ibglfx + sedf7mxb-1;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9m0ibglfx += *fpdlcqk9w8znmyce++ * *fpdlcqk9zshtfg8c;
           fpdlcqk9w8znmyce++;
           fpdlcqk9m0ibglfx += *wy1vqfzu;
        }
        fpdlcqk9zshtfg8c++;
      }


    } else {

      fpdlcqk9m0ibglfx = m0ibglfx + *hj3ftvzu-1;
      for (ayfnwr1v = 0; ayfnwr1v < *br5ovgcj; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx  = 0.0;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }

      fpdlcqk9zshtfg8c = zshtfg8c;
      fpdlcqk9w8znmyce  = w8znmyce; // +     (gp1jxzuh-1) * *br5ovgcj;
      for (gp1jxzuh = 1; gp1jxzuh <= *xlpjcg3s; gp1jxzuh++) {
        fpdlcqk9m0ibglfx = m0ibglfx + *hj3ftvzu-1;
        for (ayfnwr1v = 1; ayfnwr1v <= *br5ovgcj; ayfnwr1v++) {
          *fpdlcqk9m0ibglfx += *fpdlcqk9w8znmyce++ * *fpdlcqk9zshtfg8c;
           fpdlcqk9m0ibglfx += *wy1vqfzu;
        }
        fpdlcqk9zshtfg8c++;
      }
    }
  } else {
    if (*br5ovgcj != *wy1vqfzu * *ftnjamu2)  //Rprinf
      Rprintf("Error: *br5ovgcj != *wy1vqfzu * *ftnjamu2 in C_pkc4ejib\n");
    fpdlcqk9m0ibglfx  = m0ibglfx;
    fpdlcqk9f9piukdx = w8znmyce;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
        *fpdlcqk9m0ibglfx = 0.0e0;
        fpdlcqk9zshtfg8c = zshtfg8c;
        fpdlcqk9w8znmyce  = fpdlcqk9f9piukdx++;
        for (gp1jxzuh = 1; gp1jxzuh <= *xlpjcg3s; gp1jxzuh++) {
          *fpdlcqk9m0ibglfx += *fpdlcqk9w8znmyce * *fpdlcqk9zshtfg8c++;
          fpdlcqk9w8znmyce  += *br5ovgcj;
        }
        fpdlcqk9m0ibglfx++;
      }
    }
  }

  fpdlcqk9vm4xjosb = vm4xjosb;
  if (*unhycz0e == 1) {
    if (*qfx3vhct == 3 || *qfx3vhct == 5) {
      fpdlcqk9m0ibglfx = m0ibglfx + 2 * *hj3ftvzu - 2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb++;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    } else {
      fpdlcqk9m0ibglfx = m0ibglfx +     *hj3ftvzu - 1;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb++;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
  }
}


void yiumjq3nnipyajc1(double m0ibglfx[], double t8hwvalr[], int *ftnjamu2, int *wy1vqfzu,
                   int *afpc0kns, int *qfx3vhct, int *hj3ftvzu) {


  int    ayfnwr1v, yq6lorbx;
  double tmpwk, *fpdlcqk9t8hwvalr, *fpdlcqk9m0ibglfx;


  if (*hj3ftvzu == 0) {
    fpdlcqk9t8hwvalr  = t8hwvalr;
    fpdlcqk9m0ibglfx = m0ibglfx;
    if (*qfx3vhct == 1) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
          tmpwk = exp(*fpdlcqk9m0ibglfx++);
          *fpdlcqk9t8hwvalr++ = tmpwk / (1.0 + tmpwk);
        }
    }
    if (*qfx3vhct == 2) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++)
          *fpdlcqk9t8hwvalr++ = exp(*fpdlcqk9m0ibglfx++);
    }
    if (*qfx3vhct == 4) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++)
          *fpdlcqk9t8hwvalr++ = 1.0e0 - exp(-exp(*fpdlcqk9m0ibglfx++));
    }
    if (*qfx3vhct == 3 || *qfx3vhct == 5) {
      if (2 * *afpc0kns != *wy1vqfzu) { //Rprintf
        Rprintf("Error: 2 * *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      } //Rprintf
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
            *fpdlcqk9t8hwvalr++ = exp(*fpdlcqk9m0ibglfx++);
             fpdlcqk9m0ibglfx++;
        }
    }
    if (*qfx3vhct == 8) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++)
          *fpdlcqk9t8hwvalr++ = *fpdlcqk9m0ibglfx++;
    }
  } else {
    fpdlcqk9t8hwvalr  =  t8hwvalr + *hj3ftvzu-1;
    fpdlcqk9m0ibglfx = m0ibglfx + *hj3ftvzu-1;
    if (*qfx3vhct == 1) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        tmpwk = exp(*fpdlcqk9m0ibglfx);
        *fpdlcqk9t8hwvalr   = tmpwk / (1.0 + tmpwk);
         fpdlcqk9t8hwvalr  += *afpc0kns;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
    if (*qfx3vhct == 2) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9t8hwvalr   = exp(*fpdlcqk9m0ibglfx);
         fpdlcqk9t8hwvalr  += *afpc0kns;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
    if (*qfx3vhct == 4) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9t8hwvalr   = 1.0e0 - exp(-exp(*fpdlcqk9m0ibglfx));
         fpdlcqk9t8hwvalr  += *afpc0kns;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
    if (*qfx3vhct == 3 || *qfx3vhct == 5) {
      fpdlcqk9t8hwvalr  =  t8hwvalr +     *hj3ftvzu-1;
      fpdlcqk9m0ibglfx = m0ibglfx + 2 * *hj3ftvzu-2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9t8hwvalr   = exp(*fpdlcqk9m0ibglfx);
         fpdlcqk9t8hwvalr  += *afpc0kns;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
    if (*qfx3vhct == 8) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9t8hwvalr   = *fpdlcqk9m0ibglfx;
         fpdlcqk9t8hwvalr  += *afpc0kns;
         fpdlcqk9m0ibglfx += *wy1vqfzu;
      }
    }
  }
}



void yiumjq3nshjlwft5(int *qfx3vhct, double tlgduey8[], double ufgqj9ck[],
                  double t8hwvalr[], int *ftnjamu2, int *wy1vqfzu, int *afpc0kns,
                  int *kvowz9ht, double m0ibglfx[], double *jxacz5qu, int *hj3ftvzu,
                  double *dn3iasxug, double *vsoihn1r, int *dqk5muto) {



  int    ayfnwr1v, yq6lorbx, lbgwvp3q;
  double txlvcey5, xd4mybgj, uqnkc6zg, hofjnx2e, smmu, afwp5imx, ivqk2ywz, qvd7yktm,
         hdqsx7bk, anopu9vi, jtnbu2hz, prev_lfu2qhid = 0.0e0, lfu2qhid = 0.0e0,
         *fpdlcqk9m0ibglfx, *fpdlcqk9t8hwvalr, *fpdlcqk9ufgqj9ck, *fpdlcqk9tlgduey8;




  if (*hj3ftvzu == 0) {
    fpdlcqk9tlgduey8 = tlgduey8;

    if (*qfx3vhct == 1 || *qfx3vhct == 4) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_shjlwft5\n");
      fpdlcqk9tlgduey8 = tlgduey8;
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) { // yyy
        fpdlcqk9t8hwvalr = t8hwvalr + yq6lorbx-1;
        fpdlcqk9ufgqj9ck = ufgqj9ck;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) { // bbb
          ivqk2ywz = *fpdlcqk9tlgduey8 > 0.0 ? *fpdlcqk9tlgduey8*log(*fpdlcqk9tlgduey8) :0.0;
          if (*fpdlcqk9tlgduey8 < 1.0e0)
            ivqk2ywz += (1.0e0 - *fpdlcqk9tlgduey8) * log(1.0e0 - *fpdlcqk9tlgduey8);
          xd4mybgj = *fpdlcqk9t8hwvalr * (1.0e0 - *fpdlcqk9t8hwvalr);
          if (xd4mybgj < *dn3iasxug) {
            smmu  = *fpdlcqk9t8hwvalr;
            qvd7yktm = *fpdlcqk9tlgduey8 *
                    ((smmu < *dn3iasxug) ? *vsoihn1r : log(smmu));
            afwp5imx = 1.0e0 - smmu;
            qvd7yktm += (afwp5imx < *dn3iasxug ? *vsoihn1r : log(afwp5imx))*
                     (1.0 - *fpdlcqk9tlgduey8);
          } else {
            qvd7yktm =     *fpdlcqk9tlgduey8  * log(      *fpdlcqk9t8hwvalr) +
                 (1.0 - *fpdlcqk9tlgduey8) * log(1.0 - *fpdlcqk9t8hwvalr);
          }
          lfu2qhid += *fpdlcqk9ufgqj9ck++ * (ivqk2ywz - qvd7yktm);
          fpdlcqk9t8hwvalr += *afpc0kns;
          fpdlcqk9tlgduey8++;
        } // bbb
        jxacz5qu[yq6lorbx] = 2.0e0 * (lfu2qhid - prev_lfu2qhid);
        prev_lfu2qhid = lfu2qhid;
      } // yyy
    }
    if (*qfx3vhct == 2) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_shjlwft5\n");
      fpdlcqk9tlgduey8 = tlgduey8;
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
        fpdlcqk9t8hwvalr = t8hwvalr + yq6lorbx-1;
        fpdlcqk9ufgqj9ck = ufgqj9ck;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          xd4mybgj = *fpdlcqk9tlgduey8 > 0.0 ?  *fpdlcqk9t8hwvalr - *fpdlcqk9tlgduey8 +
                  *fpdlcqk9tlgduey8 * log(*fpdlcqk9tlgduey8 / *fpdlcqk9t8hwvalr) :
                  *fpdlcqk9t8hwvalr - *fpdlcqk9tlgduey8;
          lfu2qhid += *fpdlcqk9ufgqj9ck++ * xd4mybgj;
          fpdlcqk9t8hwvalr += *afpc0kns;
          fpdlcqk9tlgduey8++;
        }
        jxacz5qu[yq6lorbx] = 2.0e0 * (lfu2qhid - prev_lfu2qhid);
        prev_lfu2qhid = lfu2qhid;
      }
    }
    if (*qfx3vhct == 5) {
      fpdlcqk9tlgduey8 = tlgduey8;
      if (2 * *afpc0kns != *wy1vqfzu) { //Rprintf
        Rprintf("Error: 2 * *afpc0kns != *wy1vqfzu in C_nipyajc1\n");
      } //Rprintf
      for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
        fpdlcqk9m0ibglfx = m0ibglfx + 2*yq6lorbx-1;
        fpdlcqk9t8hwvalr = t8hwvalr + yq6lorbx-1;
        fpdlcqk9ufgqj9ck = ufgqj9ck;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            jtnbu2hz = exp(*fpdlcqk9m0ibglfx);
            uqnkc6zg = fvlmz9iyC_tldz5ion(jtnbu2hz);
              xd4mybgj = *fpdlcqk9tlgduey8 > 0.0 ?  (jtnbu2hz - 1.0e0) *
                      log(*fpdlcqk9tlgduey8) + (log(jtnbu2hz) -
                          *fpdlcqk9tlgduey8  / *fpdlcqk9t8hwvalr -
                      log(*fpdlcqk9t8hwvalr)) * jtnbu2hz - uqnkc6zg :
                     -1000.0e0;
              xd4mybgj   = -xd4mybgj;
              lfu2qhid += *fpdlcqk9ufgqj9ck++ * xd4mybgj;
              fpdlcqk9m0ibglfx += *wy1vqfzu;
              fpdlcqk9t8hwvalr  += *afpc0kns;
              fpdlcqk9tlgduey8++;
          }
          jxacz5qu[yq6lorbx] = 2.0e0 * (lfu2qhid - prev_lfu2qhid);
          prev_lfu2qhid = lfu2qhid;
        }
    }
    if (*qfx3vhct == 3) {
      if (*dqk5muto == 0) {
        anopu9vi = 34.0e0;
        for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            if (m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1)* *wy1vqfzu] >  anopu9vi) {
              hdqsx7bk = exp(anopu9vi);
              lbgwvp3q = 1;
            } else
            if (m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1)* *wy1vqfzu] < -anopu9vi) {
              hdqsx7bk = exp(-anopu9vi);
              lbgwvp3q = 1;
            } else {
              hdqsx7bk = exp(m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1) * *wy1vqfzu]);
              lbgwvp3q = 0;
            }
            xd4mybgj = (tlgduey8[ayfnwr1v-1+ (yq6lorbx-1)* *ftnjamu2] < 1.0e0) ?
             1.0e0 : tlgduey8[ayfnwr1v-1+ (yq6lorbx-1)* *ftnjamu2];
            lfu2qhid += ufgqj9ck[ayfnwr1v-1] *
                      (tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2] *
            log(xd4mybgj/t8hwvalr[yq6lorbx-1 + (ayfnwr1v-1) * *afpc0kns]) +
                      (tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2] +
                          hdqsx7bk) *
                 log((t8hwvalr[yq6lorbx-1 + (ayfnwr1v-1) * *afpc0kns ] +
                          hdqsx7bk) / (hdqsx7bk +
                       tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2])));
          }
              jxacz5qu[yq6lorbx] = 2.0e0 * (lfu2qhid - prev_lfu2qhid);
              prev_lfu2qhid = lfu2qhid;
            }
      } else {
        anopu9vi = 34.0e0;
        for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            if (m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1)* *wy1vqfzu] >  anopu9vi) {
              hdqsx7bk = exp(anopu9vi);
              lbgwvp3q = 1;
            } else
            if (m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1)* *wy1vqfzu] < -anopu9vi) {
              hdqsx7bk = exp(-anopu9vi);
              lbgwvp3q = 1;
            } else {
              hdqsx7bk = exp(m0ibglfx[2*yq6lorbx-1 + (ayfnwr1v-1)* *wy1vqfzu]);
              lbgwvp3q = 0;
            }
            if (lbgwvp3q) {
                  uqnkc6zg = hofjnx2e = 0.0e0;
              } else {
                  uqnkc6zg = fvlmz9iyC_tldz5ion(hdqsx7bk +
                          tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2]);
                  hofjnx2e = fvlmz9iyC_tldz5ion(hdqsx7bk);
              }
              txlvcey5 = fvlmz9iyC_tldz5ion(1.0e0 +
                      tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2]);
              xd4mybgj = hdqsx7bk * log(hdqsx7bk / (hdqsx7bk +
                      t8hwvalr[yq6lorbx-1 + (ayfnwr1v-1) * *afpc0kns])) +
                      uqnkc6zg - hofjnx2e - txlvcey5;
              if (tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2] > 0.0e0) {
                xd4mybgj += tlgduey8[ayfnwr1v-1 + (yq6lorbx-1) * *ftnjamu2] *
                         log(t8hwvalr[yq6lorbx-1 + (ayfnwr1v-1) * *afpc0kns]
                 / (hdqsx7bk + t8hwvalr[yq6lorbx-1 + (ayfnwr1v-1) * *afpc0kns]));
              }
              lfu2qhid += ufgqj9ck[ayfnwr1v-1] * xd4mybgj;
          }
          jxacz5qu[yq6lorbx] = 2.0 * (-0.5 * lfu2qhid + 0.5 * prev_lfu2qhid);
          prev_lfu2qhid = lfu2qhid;
        }
        lfu2qhid *= (-0.5);
      }
    }
    if (*qfx3vhct == 8) {
      fpdlcqk9tlgduey8 = tlgduey8;
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
        fpdlcqk9t8hwvalr = t8hwvalr + yq6lorbx-1;
        fpdlcqk9ufgqj9ck = ufgqj9ck;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          xd4mybgj       = *fpdlcqk9tlgduey8++ - *fpdlcqk9t8hwvalr;
          lfu2qhid     += *fpdlcqk9ufgqj9ck++ * pow(xd4mybgj, (double) 2.0);
          fpdlcqk9t8hwvalr += *afpc0kns;
        }
        jxacz5qu[yq6lorbx] = 2.0e0 * (lfu2qhid - prev_lfu2qhid);
        prev_lfu2qhid = lfu2qhid;
      }
    }
  } else {
     fpdlcqk9tlgduey8 = tlgduey8 + (*hj3ftvzu-1) * *ftnjamu2;
     fpdlcqk9t8hwvalr = t8hwvalr + *hj3ftvzu-1;
     fpdlcqk9ufgqj9ck = ufgqj9ck;

      if (*qfx3vhct == 1 || *qfx3vhct == 4) {
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
              ivqk2ywz = *fpdlcqk9tlgduey8 > 0.0 ? *fpdlcqk9tlgduey8 * log(*fpdlcqk9tlgduey8) : 0.0;
              if (*fpdlcqk9tlgduey8 < 1.0e0)
                  ivqk2ywz += (1.0e0 - *fpdlcqk9tlgduey8) * log(1.0e0 - *fpdlcqk9tlgduey8);
              xd4mybgj = *fpdlcqk9t8hwvalr * (1.0e0 - *fpdlcqk9t8hwvalr);
              if (xd4mybgj < *dn3iasxug) {
                  smmu  =  *fpdlcqk9t8hwvalr;
                  qvd7yktm =  *fpdlcqk9tlgduey8 *
                           ((smmu < *dn3iasxug) ?  *vsoihn1r : log(smmu));
                  afwp5imx = 1.0e0 - smmu;
                  qvd7yktm += (afwp5imx < *dn3iasxug ? *vsoihn1r : log(afwp5imx)) *
                           (1.0 - *fpdlcqk9tlgduey8);
              } else {
                  qvd7yktm  =        *fpdlcqk9tlgduey8  * log(        *fpdlcqk9t8hwvalr) +
                           (1.0 - *fpdlcqk9tlgduey8) * log(1.0e0 - *fpdlcqk9t8hwvalr);
              }
              lfu2qhid += *fpdlcqk9ufgqj9ck++ * (ivqk2ywz - qvd7yktm);
              fpdlcqk9t8hwvalr += *afpc0kns;
              fpdlcqk9tlgduey8++;
          }
      }
    if (*qfx3vhct == 2) {
      if (*afpc0kns != *wy1vqfzu)
        Rprintf("Error: *afpc0kns != *wy1vqfzu in C_shjlwft5\n");
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        xd4mybgj = *fpdlcqk9tlgduey8 > 0.0e0 ?  *fpdlcqk9t8hwvalr - *fpdlcqk9tlgduey8 +
                *fpdlcqk9tlgduey8 * log(*fpdlcqk9tlgduey8 / *fpdlcqk9t8hwvalr) :
                *fpdlcqk9t8hwvalr - *fpdlcqk9tlgduey8;
        lfu2qhid += *fpdlcqk9ufgqj9ck++ * xd4mybgj;
        fpdlcqk9t8hwvalr += *afpc0kns;
        fpdlcqk9tlgduey8++;
      }
    }
    if (*qfx3vhct == 5) {
      fpdlcqk9tlgduey8   =   tlgduey8 + (*hj3ftvzu-1) * *ftnjamu2;
      fpdlcqk9t8hwvalr  =  t8hwvalr +  *hj3ftvzu-1;
      fpdlcqk9ufgqj9ck  =  ufgqj9ck;
      fpdlcqk9m0ibglfx = m0ibglfx + 2 * *hj3ftvzu-1;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        jtnbu2hz = exp(*fpdlcqk9m0ibglfx);
        uqnkc6zg = fvlmz9iyC_tldz5ion(jtnbu2hz);
        xd4mybgj = *fpdlcqk9tlgduey8 > 0.0 ? (jtnbu2hz - 1.0e0) *
                 log(*fpdlcqk9tlgduey8) + jtnbu2hz * (log(jtnbu2hz) -
                 *fpdlcqk9tlgduey8 / *fpdlcqk9t8hwvalr - log(*fpdlcqk9t8hwvalr)) -
                 uqnkc6zg : -1000.0e0;
        xd4mybgj   = -xd4mybgj;
        lfu2qhid += *fpdlcqk9ufgqj9ck++ * xd4mybgj;
        fpdlcqk9t8hwvalr  += *afpc0kns;
        fpdlcqk9m0ibglfx += *wy1vqfzu;
        fpdlcqk9tlgduey8++;
      }
    }
    if (*qfx3vhct == 3) {
      if (*dqk5muto == 0) {
          anopu9vi = 34.0e0;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            if (m0ibglfx[2 * *hj3ftvzu -1 + (ayfnwr1v-1) * *wy1vqfzu] >  anopu9vi) {
              hdqsx7bk = exp(anopu9vi);
              lbgwvp3q = 1;
            } else
            if (m0ibglfx[2 * *hj3ftvzu -1 + (ayfnwr1v-1) * *wy1vqfzu] < -anopu9vi) {
              hdqsx7bk = exp(-anopu9vi);
              lbgwvp3q = 1;
            } else {
                hdqsx7bk = exp(m0ibglfx[2* *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu]);
                lbgwvp3q = 0;
            }
            xd4mybgj =  (tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] < 1.0e0) ?
              1.0e0 : tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2];
            lfu2qhid +=        ufgqj9ck[ayfnwr1v-1] *
                             (tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] *
                   log(xd4mybgj/t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns]) +
                   (tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] + hdqsx7bk) *
              log((t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns] + hdqsx7bk)
          / (hdqsx7bk+tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2])));
        }
    } else {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        hdqsx7bk = exp(m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu]);
        uqnkc6zg = fvlmz9iyC_tldz5ion(hdqsx7bk + tlgduey8[ayfnwr1v-1 +
                              (*hj3ftvzu-1) * *ftnjamu2]);
        hofjnx2e = fvlmz9iyC_tldz5ion(hdqsx7bk);
        txlvcey5 = fvlmz9iyC_tldz5ion(1.0e0 + tlgduey8[ayfnwr1v-1 +
                              (*hj3ftvzu-1) * *ftnjamu2]);
        xd4mybgj = hdqsx7bk * log(hdqsx7bk / (hdqsx7bk + t8hwvalr[*hj3ftvzu-1 +
                (ayfnwr1v-1) * *afpc0kns])) + uqnkc6zg - hofjnx2e - txlvcey5;

        if (tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] > 0.0e0) {
            xd4mybgj += tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] *
                log(t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns]
        / (hdqsx7bk + t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns]));
        }
        lfu2qhid += ufgqj9ck[ayfnwr1v-1] * xd4mybgj;
      }
        lfu2qhid *= (-0.5e0);
      }
    }
    if (*qfx3vhct == 8) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        lfu2qhid += *fpdlcqk9ufgqj9ck++ *
                  pow(*fpdlcqk9tlgduey8++ - *fpdlcqk9t8hwvalr, (double) 2.0);
        fpdlcqk9t8hwvalr += *afpc0kns;
      }
    }
  }
  *jxacz5qu = 2.0e0 * lfu2qhid;
}


void yiumjq3nflncwkfq76(double lncwkfq7[], double w8znmyce[], int *ftnjamu2,
                   int *br5ovgcj, int *xwdf5ltg, int *qfx3vhct) {


  int    ayfnwr1v, hpmwnav2;  // sedf7mxb = 1;
  double *fpdlcqk9w8znmyce, *fpdlcqk9lncwkfq7;

  fpdlcqk9w8znmyce = w8znmyce;
  fpdlcqk9lncwkfq7  =  lncwkfq7;

  if (*qfx3vhct == 3 || *qfx3vhct == 5) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9w8znmyce++ = 1.0e0;
      *fpdlcqk9w8znmyce++ = 0.0e0;
    }
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9w8znmyce++ = 0.0e0;
      *fpdlcqk9w8znmyce++ = 1.0e0;
    }
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq7++;
        *fpdlcqk9w8znmyce++ = 0.0e0;
      }
    }
  } else {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9w8znmyce++ = 1.0e0;
    }
    if (*br5ovgcj != *ftnjamu2)
      Rprintf("Error: *br5ovgcj != *ftnjamu2 in C_flncwkfq76\n");
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq7++;
      }
    }
  }
}


void yiumjq3nflncwkfq71(double lncwkfq7[], double w8znmyce[], int *ftnjamu2, int *xwdf5ltg,
                   int *qfx3vhct, double vm4xjosb[], int *br5ovgcj, int *xlpjcg3s,
                   double kifxa0he[], int *yru9olks, int *unhycz0e) {


  int    i0spbklx, ayfnwr1v, hpmwnav2, // sedf7mxb = *xwdf5ltg + 1,
         hyqwtp6i = *xwdf5ltg * (*xwdf5ltg + 1) / 2;
  double *fpdlcqk9lncwkfq7, *fpdlcqk9lncwkfq71, *fpdlcqk9lncwkfq72,
         *fpdlcqk9w8znmyce, *fpdlcqk9vm4xjosb,  *fpdlcqk9kifxa0he;

  int    *wkumc9idtgiyxdw1, *wkumc9iddufozmt7;
  wkumc9idtgiyxdw1  = Calloc(hyqwtp6i, int);
  wkumc9iddufozmt7  = Calloc(hyqwtp6i, int);
  fvlmz9iyC_qpsedg8x(wkumc9idtgiyxdw1, wkumc9iddufozmt7, xwdf5ltg);

  fpdlcqk9w8znmyce = w8znmyce;
  fpdlcqk9lncwkfq7  =
  fpdlcqk9lncwkfq71 =
  fpdlcqk9lncwkfq72 =  lncwkfq7;

  if (*qfx3vhct == 3 || *qfx3vhct == 5) { // ggg
    if (*br5ovgcj != 2 * *ftnjamu2)  //Rprinf
      Rprintf("Error: *br5ovgcj != 2 * *ftnjamu2 in C_flncwkfq71\n");
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq7++;
        *fpdlcqk9w8znmyce++ = 0.0e0;
      }
    }

  if (*unhycz0e == 0) {
    for (i0spbklx = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
      fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
      fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
        *fpdlcqk9w8znmyce++ = 0.0e0;
      }
    }
  } else {
    fpdlcqk9vm4xjosb = vm4xjosb;
    for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++)
      *fpdlcqk9vm4xjosb++ = 0.0;

    fpdlcqk9lncwkfq7 = lncwkfq7;
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      fpdlcqk9vm4xjosb  = vm4xjosb;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9vm4xjosb += pow(*fpdlcqk9lncwkfq7++, (double) 2.0);
         fpdlcqk9vm4xjosb++;
      }
    }

    fpdlcqk9vm4xjosb = vm4xjosb;
    for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9vm4xjosb   *= (-0.50e0);
       fpdlcqk9vm4xjosb++;
    }
  }

  } else { // ggg and hhh
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq7++;
      }
    }

  if (*unhycz0e == 0) {
    for (i0spbklx  = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
      fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
      fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
      }
    }
  } else {
    fpdlcqk9vm4xjosb = vm4xjosb;
    for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++)
      *fpdlcqk9vm4xjosb++ = 0.0;

    fpdlcqk9lncwkfq7 = lncwkfq7;
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      fpdlcqk9vm4xjosb  = vm4xjosb;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9vm4xjosb += pow(*fpdlcqk9lncwkfq7++, (double) 2.0);
         fpdlcqk9vm4xjosb++;
      }
    }

    fpdlcqk9vm4xjosb = vm4xjosb;
    for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9vm4xjosb   *= (-0.50e0);
       fpdlcqk9vm4xjosb++;
    }
    }
  } // hhh

  if (*yru9olks > 0) {
    if (*qfx3vhct == 3 || *qfx3vhct == 5) { // kkk
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = 1.0e0;
        *fpdlcqk9w8znmyce++ = 0.0e0;
      }
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9w8znmyce++ = 0.0e0;
        *fpdlcqk9w8znmyce++ = 1.0e0;
      }
      if (*yru9olks > 1) {
        fpdlcqk9kifxa0he  = kifxa0he; //  + (i0spbklx-1) * *ftnjamu2;
        for (i0spbklx = 2; i0spbklx <= *yru9olks; i0spbklx++) {
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9w8znmyce++ = *fpdlcqk9kifxa0he++;
            *fpdlcqk9w8znmyce++ = 0.0e0;
          }
        }
      }
    } else { // kkk and iii
      fpdlcqk9kifxa0he  = kifxa0he; //   + (i0spbklx-1) * *ftnjamu2;
      for (i0spbklx = 1; i0spbklx <= *yru9olks; i0spbklx++) {
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9w8znmyce++ = *fpdlcqk9kifxa0he++;
        }
      }
    } // iii
  } // if (*yru9olks > 0)
  Free(wkumc9idtgiyxdw1);    Free(wkumc9iddufozmt7);
}


void yiumjq3nflncwkfq72(double lncwkfq7[], double w8znmyce[], int *ftnjamu2, int *wy1vqfzu,
                   int *br5ovgcj, int *xwdf5ltg, int *qfx3vhct, int *afpc0kns,
                   int *fmzq7aob, int *eu3oxvyb, int *unhycz0e, double vm4xjosb[]) {




  int    i0spbklx, ayfnwr1v, yq6lorbx, gp1jxzuh, hpmwnav2, sedf7mxb = 0,
         hyqwtp6i = *xwdf5ltg * (*xwdf5ltg + 1) / 2;
  double uqnkc6zg, *fpdlcqk9lncwkfq7, *fpdlcqk9lncwkfq71, *fpdlcqk9lncwkfq72,
         *fpdlcqk9w8znmyce, *fpdlcqk9vm4xjosb;


  int    *wkumc9idtgiyxdw1, *wkumc9iddufozmt7;
  wkumc9idtgiyxdw1  = Calloc(hyqwtp6i, int);
  wkumc9iddufozmt7  = Calloc(hyqwtp6i, int);
  fvlmz9iyC_qpsedg8x(wkumc9idtgiyxdw1, wkumc9iddufozmt7, xwdf5ltg);


  fpdlcqk9w8znmyce = w8znmyce;
  fpdlcqk9lncwkfq7  =  lncwkfq7;

  for (gp1jxzuh = 1; gp1jxzuh <= *eu3oxvyb; gp1jxzuh++) {
    for (ayfnwr1v = 1; ayfnwr1v <= *br5ovgcj; ayfnwr1v++)
      *fpdlcqk9w8znmyce++ = 0.0e0;
  }
  fpdlcqk9w8znmyce = w8znmyce;

  if (*qfx3vhct == 3 || *qfx3vhct == 5) {

    if (*br5ovgcj != 2 * *ftnjamu2)  //Rprinf
      Rprintf("Error: *br5ovgcj != 2 * *ftnjamu2 in C_flncwkfq72\n");
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      fpdlcqk9w8znmyce = w8znmyce +  sedf7mxb      * *br5ovgcj;
      fpdlcqk9lncwkfq7  =  lncwkfq7 + (hpmwnav2-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
            *fpdlcqk9w8znmyce = *fpdlcqk9lncwkfq7;
            fpdlcqk9w8znmyce += 2 + *br5ovgcj;
        }
        fpdlcqk9lncwkfq7++;
        fpdlcqk9w8znmyce -= *afpc0kns * *br5ovgcj;  // fixed@20100406
      }
      sedf7mxb += *afpc0kns;
    }
  } else {
    for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
      fpdlcqk9w8znmyce = w8znmyce +  sedf7mxb      * *br5ovgcj;
      fpdlcqk9lncwkfq7  =  lncwkfq7 + (hpmwnav2-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
          *fpdlcqk9w8znmyce++  = *fpdlcqk9lncwkfq7;
           fpdlcqk9w8znmyce   += *br5ovgcj;
        }
        fpdlcqk9lncwkfq7++;
        fpdlcqk9w8znmyce -= *wy1vqfzu * *br5ovgcj;  // fixed@20100406
      }
      sedf7mxb += *wy1vqfzu;
    }
  }

  if (*fmzq7aob == 0) {
    if (*qfx3vhct == 3 || *qfx3vhct == 5) {
      for (i0spbklx = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
        fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
        fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
        fpdlcqk9w8znmyce = w8znmyce +  sedf7mxb                     * *br5ovgcj;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          uqnkc6zg = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
          for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
            *fpdlcqk9w8znmyce  = uqnkc6zg;
             fpdlcqk9w8znmyce += 2 + *br5ovgcj;
          }
          fpdlcqk9w8znmyce -= *afpc0kns * *br5ovgcj;  // fixed@20100406
        }
        sedf7mxb += *afpc0kns;
      }
    } else {
      for (i0spbklx = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
        fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
        fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
        fpdlcqk9w8znmyce = w8znmyce +  sedf7mxb                     * *br5ovgcj;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          uqnkc6zg = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
          for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
            *fpdlcqk9w8znmyce++  = uqnkc6zg;
             fpdlcqk9w8znmyce   += *br5ovgcj;
          }
          fpdlcqk9w8znmyce -= *wy1vqfzu * *br5ovgcj;  // fixed@20100406
        }
        sedf7mxb += *wy1vqfzu;
      }
    }
  } else {
    if (*unhycz0e == 1) {

      fpdlcqk9vm4xjosb = vm4xjosb;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++)
        *fpdlcqk9vm4xjosb++ = 0.0;

      fpdlcqk9lncwkfq7 = lncwkfq7;
      for (hpmwnav2 = 1; hpmwnav2 <= *xwdf5ltg; hpmwnav2++) {
        fpdlcqk9vm4xjosb  = vm4xjosb;
        for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9vm4xjosb += pow(*fpdlcqk9lncwkfq7++, (double) 2.0);
           fpdlcqk9vm4xjosb++;
        }
      }

      fpdlcqk9vm4xjosb = vm4xjosb;
      for (ayfnwr1v = 0; ayfnwr1v < *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9vm4xjosb   *= (-0.50e0);
         fpdlcqk9vm4xjosb++;
      }
    } else {
      if (*qfx3vhct == 3 || *qfx3vhct == 5) {
        for (i0spbklx = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
          fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
          fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
          fpdlcqk9w8znmyce = w8znmyce + (sedf7mxb+i0spbklx-1) * *br5ovgcj;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            uqnkc6zg = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
            for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
              *fpdlcqk9w8znmyce++ = uqnkc6zg;
               fpdlcqk9w8znmyce++;
            }
          }
        }
        sedf7mxb += hyqwtp6i;
      } else {
        for (i0spbklx = 1; i0spbklx <= hyqwtp6i; i0spbklx++) {
          fpdlcqk9lncwkfq71 =  lncwkfq7 + (wkumc9idtgiyxdw1[i0spbklx-1]-1) * *ftnjamu2;
          fpdlcqk9lncwkfq72 =  lncwkfq7 + (wkumc9iddufozmt7[i0spbklx-1]-1) * *ftnjamu2;
          fpdlcqk9w8znmyce = w8znmyce + (sedf7mxb+i0spbklx-1) * *br5ovgcj;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            uqnkc6zg = *fpdlcqk9lncwkfq71++ * *fpdlcqk9lncwkfq72++;
            for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++)
              *fpdlcqk9w8znmyce++ = uqnkc6zg;
          }
        }
        sedf7mxb += hyqwtp6i;
      }
    }
  }
  Free(wkumc9idtgiyxdw1);     Free(wkumc9iddufozmt7);
}


void yiumjq3nietam6(double tlgduey8[], double m0ibglfx[], double y7sdgtqi[],
                  int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *qfx3vhct,
                  int *hj3ftvzu, double ufgqj9ck[], int *wr0lbopv) {


  int    ayfnwr1v;
  double gyuq8dex, g2vwexykp, qa8ltuhj, vogkfwt8 = 0.0e0, msrdjh5f = 0.0e0,
         kwvo4ury, cpz4fgkx, tad5vhsu, khl0iysgk, myoffset = 1.0 / 32.0;
  double *fpdlcqk9tlgduey8, *fpdlcqk9m0ibglfx, *fpdlcqk9m0ibglfx1, *fpdlcqk9m0ibglfx2,
         *fpdlcqk9ufgqj9ck;


  fpdlcqk9m0ibglfx  =
  fpdlcqk9m0ibglfx1 =
  fpdlcqk9m0ibglfx2 = &tad5vhsu;
  gyuq8dex = 1.0;



  fpdlcqk9tlgduey8    =   tlgduey8 + (*hj3ftvzu-1) * *ftnjamu2;
  fpdlcqk9ufgqj9ck   =  ufgqj9ck;
  if (*qfx3vhct == 3 || *qfx3vhct == 5) {
    fpdlcqk9m0ibglfx1 = m0ibglfx + 2 * *hj3ftvzu-1;
    fpdlcqk9m0ibglfx2 = m0ibglfx + 2 * *hj3ftvzu-2;
  } else {
    fpdlcqk9m0ibglfx  = m0ibglfx +     *hj3ftvzu-1;
  }

  if (*qfx3vhct == 1 || *qfx3vhct == 4 ||
      *qfx3vhct == 3 || *qfx3vhct == 5) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      msrdjh5f  += *fpdlcqk9ufgqj9ck;
      vogkfwt8 += *fpdlcqk9tlgduey8++ * *fpdlcqk9ufgqj9ck++;
    }
    gyuq8dex = vogkfwt8 / msrdjh5f;
    fpdlcqk9tlgduey8    =   tlgduey8 + (*hj3ftvzu-1) * *ftnjamu2;
  }
  if (*qfx3vhct == 1) {
    yiumjq3ng2vwexyk9(&gyuq8dex, &g2vwexykp);
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9m0ibglfx  = g2vwexykp;
       fpdlcqk9m0ibglfx += *wy1vqfzu;
    }
  }
  if (*qfx3vhct == 2) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9m0ibglfx  = log(*fpdlcqk9tlgduey8++ + myoffset);
       fpdlcqk9m0ibglfx += *wy1vqfzu;
    }
  }
  if (*qfx3vhct == 4) {
    yiumjq3nbewf1pzv9(&gyuq8dex, &qa8ltuhj);
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9m0ibglfx  = qa8ltuhj;
       fpdlcqk9m0ibglfx += *wy1vqfzu;
    }
  }
  if (*qfx3vhct == 5) {
    if (*wr0lbopv == 1 || *wr0lbopv == 2) {
      kwvo4ury = *wr0lbopv == 1 ? log(gyuq8dex + myoffset) :
                                 log((6.0 / 8.0) * gyuq8dex);
      cpz4fgkx = log(y7sdgtqi[3 + *afpc0kns + *hj3ftvzu -1] + myoffset);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx2  = kwvo4ury;
        *fpdlcqk9m0ibglfx1  = cpz4fgkx;
         fpdlcqk9m0ibglfx1 += *wy1vqfzu;
         fpdlcqk9m0ibglfx2 += *wy1vqfzu;
      }
    } else {
      cpz4fgkx = log(y7sdgtqi[3 + *afpc0kns + *hj3ftvzu -1] + myoffset);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx2  = log(*fpdlcqk9tlgduey8++ + myoffset);
        *fpdlcqk9m0ibglfx1  = cpz4fgkx;
         fpdlcqk9m0ibglfx1 += *wy1vqfzu;
         fpdlcqk9m0ibglfx2 += *wy1vqfzu;
      }
    }
  }
  if (*qfx3vhct == 3) {
    if (*wr0lbopv == 1) {
      kwvo4ury = log(gyuq8dex + myoffset);
      cpz4fgkx = log(y7sdgtqi[3 + *hj3ftvzu -1] + myoffset);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx2  = kwvo4ury;
        *fpdlcqk9m0ibglfx1  = cpz4fgkx;
         fpdlcqk9m0ibglfx1 += *wy1vqfzu;
         fpdlcqk9m0ibglfx2 += *wy1vqfzu;
      }
    } else if (*wr0lbopv == 2) {
      kwvo4ury = log(gyuq8dex + myoffset);
      khl0iysgk   = y7sdgtqi[3 + *hj3ftvzu -1];
      cpz4fgkx = log(khl0iysgk);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        tad5vhsu = *fpdlcqk9tlgduey8 - gyuq8dex;
        *fpdlcqk9m0ibglfx2  = (tad5vhsu < 3.0 * gyuq8dex) ? kwvo4ury :
                         log(sqrt(*fpdlcqk9tlgduey8));
        *fpdlcqk9m0ibglfx1  = cpz4fgkx;
         fpdlcqk9m0ibglfx1 += *wy1vqfzu;
         fpdlcqk9m0ibglfx2 += *wy1vqfzu;
         fpdlcqk9tlgduey8++;
      }
    } else if (*wr0lbopv == 3) {
      kwvo4ury = log(gyuq8dex + myoffset);
      khl0iysgk = y7sdgtqi[3 + *hj3ftvzu -1];
      cpz4fgkx = log(khl0iysgk);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        tad5vhsu = *fpdlcqk9tlgduey8 - gyuq8dex;
        if (tad5vhsu > gyuq8dex) {
          *fpdlcqk9m0ibglfx2 = log(0.5 * (*fpdlcqk9tlgduey8 + gyuq8dex));
          *fpdlcqk9m0ibglfx1 = log(khl0iysgk / (tad5vhsu / gyuq8dex));
        } else
        if (*fpdlcqk9tlgduey8 < (gyuq8dex / 4.0)) {
          *fpdlcqk9m0ibglfx2 = log(gyuq8dex / 4.0);
          *fpdlcqk9m0ibglfx1 = cpz4fgkx;
        } else {
          *fpdlcqk9m0ibglfx2 = kwvo4ury;
          *fpdlcqk9m0ibglfx1 = cpz4fgkx;
        }
        fpdlcqk9m0ibglfx1 += *wy1vqfzu;
        fpdlcqk9m0ibglfx2 += *wy1vqfzu;
        fpdlcqk9tlgduey8++;
      }
    } else {
      cpz4fgkx = log(y7sdgtqi[3 + *hj3ftvzu - 1]);
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9m0ibglfx2  = log(*fpdlcqk9tlgduey8++ + myoffset);
        *fpdlcqk9m0ibglfx1  = cpz4fgkx;
         fpdlcqk9m0ibglfx1 += *wy1vqfzu;
         fpdlcqk9m0ibglfx2 += *wy1vqfzu;
      }
    }
  }
  if (*qfx3vhct == 8) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9m0ibglfx  = *fpdlcqk9tlgduey8++;
       fpdlcqk9m0ibglfx += *wy1vqfzu;
    }
  }
}



void yiumjq3ndlgpwe0c(double tlgduey8[], double ufgqj9ck[], double m0ibglfx[],
        double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
        double wpuarq2m[], double *rsynp1go, double *dn3iasxug, double *uaf2xgqy,
        int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
        int *hj3ftvzu, int *qfx3vhct, int *zjkrtol8, int *unhycz0e, double vm4xjosb[]) {

  int    ayfnwr1v, lbgwvp3q = -7; //qfx3vhct  #  kvowz9ht
  double xd4mybgja, xd4mybgjb, xd4mybgjc, anopu9vi;
  double *fpdlcqk9m0ibglfx, *fpdlcqk9m0ibglfx1, *fpdlcqk9m0ibglfx2, *fpdlcqk9t8hwvalr,
         *fpdlcqk9vm4xjosb,   *fpdlcqk9wpuarq2m,    *fpdlcqk9ufgqj9ck,   *fpdlcqk9rbne6ouj,
         *fpdlcqk9tlgduey8,   *fpdlcqk9ghz9vuba;

  double hdqsx7bk, dkdeta, dldk, ux3nadiw, ed2ldk2, n2kersmx;
  double bzmd6ftvmat[1], kkmat[1], nm0eljqk[1];
  int    dvhw1ulq, sguwj9ty, pqneb2ra = 1;

  double jtnbu2hz, uqnkc6zgd, uqnkc6zgt, dldshape, fvn3iasxug, xk7dnvei;
  int    okobr6tcex;
  double tmp1;




  fpdlcqk9m0ibglfx  =
  fpdlcqk9m0ibglfx1 =
  fpdlcqk9m0ibglfx2 = &xd4mybgja;
  lbgwvp3q += 7;
  lbgwvp3q *= lbgwvp3q;












  n2kersmx = 0.990e0;
  n2kersmx = 0.995e0;

  fpdlcqk9m0ibglfx  = m0ibglfx  +  *hj3ftvzu-1;
  if (*qfx3vhct == 3 || *qfx3vhct == 5) {
    fpdlcqk9m0ibglfx1 = m0ibglfx  +  2 * *hj3ftvzu-1;
    fpdlcqk9m0ibglfx2 = m0ibglfx  +  2 * *hj3ftvzu-2;
  }
  fpdlcqk9t8hwvalr   =  t8hwvalr  +  *hj3ftvzu-1;
  fpdlcqk9vm4xjosb    =  vm4xjosb;
  fpdlcqk9wpuarq2m    =   wpuarq2m  +  *hj3ftvzu-1;
  fpdlcqk9ufgqj9ck   =  ufgqj9ck;
  fpdlcqk9rbne6ouj   =  rbne6ouj  + (*hj3ftvzu-1) * *ftnjamu2;
  fpdlcqk9tlgduey8    =   tlgduey8  + (*hj3ftvzu-1) * *ftnjamu2;
  fpdlcqk9ghz9vuba    =   ghz9vuba  + (*hj3ftvzu-1) * *ftnjamu2;

  if (*qfx3vhct == 1) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      xd4mybgja = *fpdlcqk9t8hwvalr * (1.0e0 - *fpdlcqk9t8hwvalr);
      xd4mybgjb = xd4mybgja * *fpdlcqk9ufgqj9ck++;
      if (xd4mybgja < *dn3iasxug) xd4mybgja = *dn3iasxug;
      if (xd4mybgjb < *dn3iasxug) {
        xd4mybgjb = *dn3iasxug;
        *fpdlcqk9wpuarq2m = *uaf2xgqy;
      } else {
        *fpdlcqk9wpuarq2m = sqrt(xd4mybgjb);
      }
      *fpdlcqk9rbne6ouj++ = xd4mybgjb;
      *fpdlcqk9ghz9vuba++  = *fpdlcqk9m0ibglfx +
                     (*fpdlcqk9tlgduey8++ - *fpdlcqk9t8hwvalr) / xd4mybgja;
      fpdlcqk9t8hwvalr  += *afpc0kns;
      fpdlcqk9wpuarq2m   += *npjlv3mr;
      fpdlcqk9m0ibglfx += *wy1vqfzu;
    }
  }
  if (*qfx3vhct == 2) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      xd4mybgja = *fpdlcqk9t8hwvalr;
      xd4mybgjb = xd4mybgja * *fpdlcqk9ufgqj9ck++;
      if (xd4mybgjb < *dn3iasxug) {
        xd4mybgjb = *dn3iasxug;
        *fpdlcqk9wpuarq2m = *uaf2xgqy;
      } else {
        *fpdlcqk9wpuarq2m = sqrt(xd4mybgjb);
      }
      *fpdlcqk9rbne6ouj = xd4mybgjb;
      if (*fpdlcqk9tlgduey8 > 0.0e0) {
        xd4mybgjc = xd4mybgja;
        if (xd4mybgjc < *dn3iasxug)
          xd4mybgjc = *dn3iasxug;
        *fpdlcqk9ghz9vuba = *fpdlcqk9m0ibglfx + (*fpdlcqk9tlgduey8 - xd4mybgjc) / xd4mybgjc;
      } else {
        *fpdlcqk9ghz9vuba = *fpdlcqk9m0ibglfx - 1.0e0;
      }
      fpdlcqk9m0ibglfx += *wy1vqfzu;
      fpdlcqk9t8hwvalr  += *afpc0kns;
      fpdlcqk9wpuarq2m   += *npjlv3mr;
      fpdlcqk9rbne6ouj++;
      fpdlcqk9tlgduey8++;
      fpdlcqk9ghz9vuba++;
    }
  }
  if (*qfx3vhct == 4) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      if (*fpdlcqk9t8hwvalr < *dn3iasxug || *fpdlcqk9t8hwvalr > 1.0e0 - *dn3iasxug) {
        xd4mybgja = *dn3iasxug;
        xd4mybgjb = xd4mybgja * *fpdlcqk9ufgqj9ck;
        if (xd4mybgjb < *dn3iasxug) {
          xd4mybgjb = *dn3iasxug;
          *fpdlcqk9wpuarq2m = *uaf2xgqy;
        } else {
          *fpdlcqk9wpuarq2m = sqrt(xd4mybgjb);
        }
        *fpdlcqk9rbne6ouj = xd4mybgjb;
        *fpdlcqk9ghz9vuba = *fpdlcqk9m0ibglfx +
                     (*fpdlcqk9tlgduey8 - *fpdlcqk9t8hwvalr) / xd4mybgja;
      } else {
        xd4mybgja =  -(1.0e0 - *fpdlcqk9t8hwvalr) * log(1.0e0 - *fpdlcqk9t8hwvalr);
        if (xd4mybgja < *dn3iasxug) {
          xd4mybgja = *dn3iasxug;
        }
        xd4mybgjb = -xd4mybgja * *fpdlcqk9ufgqj9ck *
                 log(1.0e0 - *fpdlcqk9t8hwvalr) / *fpdlcqk9t8hwvalr;
        if (xd4mybgjb < *dn3iasxug) {
            xd4mybgjb = *dn3iasxug;
        }
        *fpdlcqk9rbne6ouj = xd4mybgjb;
         *fpdlcqk9wpuarq2m = sqrt(xd4mybgjb);
         *fpdlcqk9ghz9vuba = *fpdlcqk9m0ibglfx +
                     (*fpdlcqk9tlgduey8 - *fpdlcqk9t8hwvalr) / xd4mybgja;
      }
      fpdlcqk9m0ibglfx += *wy1vqfzu;
      fpdlcqk9t8hwvalr  += *afpc0kns;
      fpdlcqk9wpuarq2m   += *npjlv3mr;
      fpdlcqk9ufgqj9ck++;
      fpdlcqk9rbne6ouj++;
      fpdlcqk9tlgduey8++;
      fpdlcqk9ghz9vuba++;
    }
  }
  if (*qfx3vhct == 5) {
    fvn3iasxug = 1.0e-20;
    anopu9vi  = 34.0e0;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      if (m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] >  anopu9vi) {
        jtnbu2hz = exp(anopu9vi);
        lbgwvp3q = 1;
      } else
      if (m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] < -anopu9vi) {
        jtnbu2hz = exp(-anopu9vi);
        lbgwvp3q = 1;
      } else {
        jtnbu2hz = exp(m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu]);
        lbgwvp3q = 0;
      }
      tyee_C_vdgam1(&jtnbu2hz, &uqnkc6zgd, &okobr6tcex);
      if (okobr6tcex != 1) {
        Rprintf("Error 1 in dlgpwe0c okobr6tcex=%d. Ploughing on.\n", okobr6tcex);
      }
      xk7dnvei = t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns];
      if (xk7dnvei < fvn3iasxug) {
        xk7dnvei = fvn3iasxug;
      }
      dldshape = log(tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2]) +
                 log(jtnbu2hz) - log(xk7dnvei) + 1.0e0 - uqnkc6zgd -
                     tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] / xk7dnvei;



      tyee_C_vtgam1(&jtnbu2hz, &uqnkc6zgt, &okobr6tcex);
      if (okobr6tcex != 1) {
        Rprintf("Error 2 in dlgpwe0c okobr6tcex=%d. Ploughing on.\n", okobr6tcex);
      }
      rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] =
      ufgqj9ck[ayfnwr1v-1] * jtnbu2hz;
      xd4mybgja = jtnbu2hz * uqnkc6zgt - 1.0e0;
      rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] =
      ufgqj9ck[ayfnwr1v-1] * jtnbu2hz * xd4mybgja;

      if (rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] < *dn3iasxug) {
        rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] = *dn3iasxug;
        wpuarq2m[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *npjlv3mr] = *uaf2xgqy;
      } else {
        wpuarq2m[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *npjlv3mr] =
            sqrt(rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2]);
      }

      if (rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] < *dn3iasxug) {
        rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] = *dn3iasxug;
        wpuarq2m[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *npjlv3mr] = *uaf2xgqy;
      } else {
        wpuarq2m[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *npjlv3mr] =
        sqrt(rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2]);
      }


      if (xd4mybgja < fvn3iasxug) {
        xd4mybgja = fvn3iasxug;
      }
      ghz9vuba[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] =
      m0ibglfx[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *wy1vqfzu] +
      tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] / xk7dnvei - 1.0e0;

      ghz9vuba[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] =
      m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] + dldshape / xd4mybgja;
    }
  }
  if (*qfx3vhct == 3) {
    anopu9vi = 34.0e0;
    fvn3iasxug = 1.0e-20;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      if (m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] >  anopu9vi) {
        hdqsx7bk = exp(anopu9vi);
        lbgwvp3q = 1;
      } else
      if (m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] < -anopu9vi) {
        hdqsx7bk = exp(-anopu9vi);
        lbgwvp3q = 1;
      } else {
        hdqsx7bk = exp(m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu]);
        lbgwvp3q = 0;
      }

      xk7dnvei = t8hwvalr[*hj3ftvzu-1 + (ayfnwr1v-1) * *afpc0kns];
      if (xk7dnvei < fvn3iasxug) { xk7dnvei = fvn3iasxug; }
        tmp1 = tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] + hdqsx7bk;
        tyee_C_vdgam1(&tmp1, &xd4mybgja, &okobr6tcex);

        if (okobr6tcex != 1) {
          Rprintf("error in dlgpwe0c okobr6tcex 3: %3d \n", okobr6tcex);
        }
        tyee_C_vdgam1(&hdqsx7bk, &xd4mybgjb, &okobr6tcex);
        if (okobr6tcex != 1) {
          Rprintf("error in dlgpwe0c okobr6tcex 4: %3d \n", okobr6tcex);
        }
        dldk = xd4mybgja - xd4mybgjb -
          (tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] + hdqsx7bk)
          / (xk7dnvei + hdqsx7bk) + 1.0 + log(hdqsx7bk / (xk7dnvei + hdqsx7bk));

      dkdeta = hdqsx7bk;

      kkmat[0] = hdqsx7bk;
      nm0eljqk[0] = xk7dnvei;
          sguwj9ty = 5000;
      fvlmz9iyC_enbin9(bzmd6ftvmat, kkmat, nm0eljqk,
                    &n2kersmx, &pqneb2ra, &dvhw1ulq, &pqneb2ra,
                    &ux3nadiw, rsynp1go, &sguwj9ty);
      if (dvhw1ulq != 1) {
          *zjkrtol8 = 5;
          Rprintf("Error. Exiting enbin9; dvhw1ulq is %d\n", dvhw1ulq);
          return;
      }

      ed2ldk2 = -bzmd6ftvmat[0] - 1.0e0 / hdqsx7bk + 1.0e0 / (hdqsx7bk + xk7dnvei);
      rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] =
      ufgqj9ck[ayfnwr1v-1] * xk7dnvei * hdqsx7bk / (xk7dnvei + hdqsx7bk);
      rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] =
      ufgqj9ck[ayfnwr1v-1] * hdqsx7bk *
            (-bzmd6ftvmat[0] * hdqsx7bk - 1.0e0 + hdqsx7bk / (hdqsx7bk + xk7dnvei));

      if (rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] < *dn3iasxug) {
        rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] = *dn3iasxug;
        wpuarq2m[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *npjlv3mr] = *uaf2xgqy;
      } else
        wpuarq2m[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *npjlv3mr] =
        sqrt(rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2]);

      if (rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] < *dn3iasxug) {
        rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] = *dn3iasxug;
        wpuarq2m[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *npjlv3mr] = *uaf2xgqy;
      } else {
        wpuarq2m[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *npjlv3mr] =
        sqrt(rbne6ouj[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2]);
      }

      ghz9vuba[ayfnwr1v-1 + (2 * *hj3ftvzu-2) * *ftnjamu2] =
      m0ibglfx[2 * *hj3ftvzu-2 + (ayfnwr1v-1) * *wy1vqfzu] +
      tlgduey8[ayfnwr1v-1 + (*hj3ftvzu-1) * *ftnjamu2] / xk7dnvei - 1.0e0;
      ghz9vuba[ayfnwr1v-1 + (2 * *hj3ftvzu-1) * *ftnjamu2] =
      m0ibglfx[2 * *hj3ftvzu-1 + (ayfnwr1v-1) * *wy1vqfzu] +
      dldk / (dkdeta * ed2ldk2);
    }
  }
  if (*qfx3vhct == 8) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9rbne6ouj  = *fpdlcqk9ufgqj9ck++;
      *fpdlcqk9wpuarq2m   = sqrt(*fpdlcqk9rbne6ouj);
      *fpdlcqk9ghz9vuba++ = *fpdlcqk9tlgduey8++;
       fpdlcqk9wpuarq2m  += *npjlv3mr;
       fpdlcqk9rbne6ouj++;
    }
  }

  if (*unhycz0e == 1) {
    fpdlcqk9ghz9vuba = ghz9vuba  + ((*qfx3vhct == 3 || *qfx3vhct == 5) ?
                (2 * *hj3ftvzu-2) : (*hj3ftvzu-1)) * *ftnjamu2;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9ghz9vuba -= *fpdlcqk9vm4xjosb++;
       fpdlcqk9ghz9vuba++;
    }
  }
}



void cqo_2(double lncwkfq7[], double tlgduey8[], double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[], double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[],
                double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                int *zjkrtol8, int xui7hqwl[],
                double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[]) {





  int    ayfnwr1v, yq6lorbx, gp1jxzuh, bpvaqm5z, yu6izdrc = 0,
         kcm6jfob, fmzq7aob, xwdf5ltg, kvowz9ht, f7svlajr, qfx3vhct, c5aesxkul, pqneb2ra = 1;
  int    ybnsqgo9, algpft4y, qemj9asg, xlpjcg3s, eu3oxvyb, vtsou9pz, unhycz0e, wr0lbopv;
  double dn3iasxug, wiptsjx8, bh2vgiay, pvofyg8z = 1.0e-7, uylxqtc7 = 0.0,
         uaf2xgqy, vsoihn1r, rsynp1go;   // rpto5qwb,
  double *qnwamo0e1,       *fpdlcqk9w8znmyce,
         *fpdlcqk9m0ibglfx, *fpdlcqk9vm4xjosb, *fpdlcqk9vc6hatuj, *fpdlcqk9wpuarq2m, *fpdlcqk9ghz9vuba;
  double hmayv1xt1 = 10.0, hmayv1xt2 = 0.0;
  int    x1jrewny = 0;


  double *wkumc9idrpto5qwb, *wkumc9idtwk;
  wkumc9idrpto5qwb = Calloc(1 + *afpc0kns        , double);
  wkumc9idtwk    = Calloc(*wy1vqfzu * *ftnjamu2 * 2, double);



  xwdf5ltg    = xui7hqwl[0];
  fmzq7aob    = xui7hqwl[1];
  xlpjcg3s   = xui7hqwl[2];
  kvowz9ht  = xui7hqwl[3];
  f7svlajr  = xui7hqwl[4];
  qfx3vhct = xui7hqwl[5];
  c5aesxkul  = xui7hqwl[6];
  xui7hqwl[8] = 0;
  eu3oxvyb  = xui7hqwl[10];
  vtsou9pz  = xui7hqwl[11];
  unhycz0e    = xui7hqwl[13];
  wr0lbopv = xui7hqwl[17];
  dn3iasxug  = y7sdgtqi[0];
  uaf2xgqy = sqrt(dn3iasxug);
  if (qfx3vhct == 1 || qfx3vhct == 4)
    vsoihn1r = log(dn3iasxug);
  bh2vgiay   = y7sdgtqi[1];
  rsynp1go = y7sdgtqi[2];





  hmayv1xt1 -= bh2vgiay;
  hmayv1xt2 -= rsynp1go;
  hmayv1xt1 += hmayv1xt2;





  *zjkrtol8 = 1;

  yiumjq3nflncwkfq72(lncwkfq7, w8znmyce, ftnjamu2, wy1vqfzu,
                br5ovgcj, &xwdf5ltg,  &qfx3vhct, afpc0kns,
                &fmzq7aob, &eu3oxvyb, &unhycz0e, vm4xjosb);

  ceqzd1hi653: hmayv1xt2 = 1.0e0;

  if (f7svlajr == 0) {
    for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
      yiumjq3nietam6(tlgduey8, m0ibglfx, y7sdgtqi, ftnjamu2,
                   wy1vqfzu, afpc0kns, &qfx3vhct, &yq6lorbx, ufgqj9ck, &wr0lbopv);
    }
  } else
  if (f7svlajr == 2) {
    yiumjq3npkc4ejib(w8znmyce, zshtfg8c, m0ibglfx,
                 ftnjamu2, wy1vqfzu, br5ovgcj, &xlpjcg3s,
                 &vtsou9pz, &yu6izdrc, &qfx3vhct, &unhycz0e,
                 vm4xjosb);
  }

  yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                afpc0kns, &qfx3vhct, &yu6izdrc);

  if (f7svlajr == 2) {
    yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                 t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                 &kvowz9ht, m0ibglfx, wkumc9idrpto5qwb, &yu6izdrc,
                 &dn3iasxug, &vsoihn1r, &pqneb2ra);
  } else {
   wkumc9idrpto5qwb[0] = -1.0e0;
  }


  for (kcm6jfob = 1; kcm6jfob <= c5aesxkul; kcm6jfob++) {

    for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
      yiumjq3ndlgpwe0c(tlgduey8, ufgqj9ck, m0ibglfx,
                   t8hwvalr, ghz9vuba, rbne6ouj,
                   wpuarq2m, &rsynp1go, &dn3iasxug, &uaf2xgqy,
                   ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
                   &yq6lorbx, &qfx3vhct, zjkrtol8, &unhycz0e, vm4xjosb);
    }


    fpdlcqk9vc6hatuj = vc6hatuj; fpdlcqk9w8znmyce = w8znmyce;
    for (yq6lorbx = 1; yq6lorbx <= xlpjcg3s; yq6lorbx++)
      for (ayfnwr1v = 1; ayfnwr1v <= *br5ovgcj; ayfnwr1v++)
         *fpdlcqk9vc6hatuj++ = *fpdlcqk9w8znmyce++;



    if (qfx3vhct == 3 || qfx3vhct == 5) {
      Rprintf("20100410; Error: this definitely does not work\n");
      if (2 * *wy1vqfzu * *ftnjamu2 != *br5ovgcj)  //Rprintf
        Rprintf("Error: 2 * *wy1vqfzu * *ftnjamu2 != *br5ovgcj in C_cqo_2\n");
      fpdlcqk9vc6hatuj = vc6hatuj;
      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
        fpdlcqk9wpuarq2m  = wpuarq2m;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          for (bpvaqm5z = 1; bpvaqm5z <= *wy1vqfzu; bpvaqm5z++) {
            *fpdlcqk9vc6hatuj *= *fpdlcqk9wpuarq2m++;
             fpdlcqk9vc6hatuj++;
          }
        }
      }
    } else {
      if (*wy1vqfzu * *ftnjamu2 != *br5ovgcj)  //Rprintf
        Rprintf("Error: *wy1vqfzu * *ftnjamu2 != *br5ovgcj in C_cqo_2\n");
      fpdlcqk9vc6hatuj = vc6hatuj;
      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
        fpdlcqk9wpuarq2m = wpuarq2m;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          for (bpvaqm5z = 1; bpvaqm5z <= *wy1vqfzu; bpvaqm5z++) {
            *fpdlcqk9vc6hatuj *= *fpdlcqk9wpuarq2m++;
             fpdlcqk9vc6hatuj++;
          }
        }
      }
    }


    for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++)
      ges1xpkr[gp1jxzuh-1] = gp1jxzuh;

    F77_CALL(vqrdca)(vc6hatuj, br5ovgcj, br5ovgcj, &xlpjcg3s, fasrkub3, ges1xpkr,
                     wkumc9idtwk, &qemj9asg, &pvofyg8z);

    if (qemj9asg != xlpjcg3s) {
      *zjkrtol8 = 2;
      Rprintf("Failure or Error in cqo_2: vc6hatuj is not of full xwdf5ltg.\n");
      Free(wkumc9idrpto5qwb);    Free(wkumc9idtwk);
      return;
    }

    if (*npjlv3mr != *wy1vqfzu)  //Rprintf
      Rprintf("Error: *wy1vqfzu != *npjlv3mr in C_cqo_2\n");
    qnwamo0e1     = wkumc9idtwk;
    fpdlcqk9wpuarq2m = wpuarq2m;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      fpdlcqk9ghz9vuba = ghz9vuba +  ayfnwr1v-1;
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
          *qnwamo0e1++    = *fpdlcqk9wpuarq2m++ * *fpdlcqk9ghz9vuba;
           fpdlcqk9ghz9vuba += *ftnjamu2;
      }
    }

    ybnsqgo9 = 101;

    F77_CALL(vdqrsl)(vc6hatuj, br5ovgcj, br5ovgcj, &qemj9asg, fasrkub3, wkumc9idtwk,
                     &uylxqtc7, wkumc9idtwk + *wy1vqfzu * *ftnjamu2, zshtfg8c,
                     &uylxqtc7, m0ibglfx, &ybnsqgo9, &algpft4y);


    if (*npjlv3mr != *wy1vqfzu)  //Rprintf
      Rprintf("Error: *wy1vqfzu != *npjlv3mr in C_cqo_2\n");
    fpdlcqk9m0ibglfx = m0ibglfx;
    fpdlcqk9wpuarq2m   = wpuarq2m;
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
         *fpdlcqk9m0ibglfx /= *fpdlcqk9wpuarq2m++;
          fpdlcqk9m0ibglfx++;
          }
    }


    if (unhycz0e == 1) {
      if (qfx3vhct == 3 || qfx3vhct == 5) {

        if (2 * *afpc0kns != *wy1vqfzu)  //Rprintf
          Rprintf("Error: 2 * *afpc0kns != *wy1vqfzu in C_cqo_2\n");

        fpdlcqk9m0ibglfx = m0ibglfx;
        fpdlcqk9vm4xjosb   = vm4xjosb;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          for (yq6lorbx = 1; yq6lorbx <= *afpc0kns; yq6lorbx++) {
            *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb;
             fpdlcqk9m0ibglfx += 2;
          }
          fpdlcqk9vm4xjosb++;
        }
      } else {
        fpdlcqk9m0ibglfx = m0ibglfx;
        fpdlcqk9vm4xjosb   = vm4xjosb;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          for (yq6lorbx = 1; yq6lorbx <= *wy1vqfzu; yq6lorbx++) {
            *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb;
             fpdlcqk9m0ibglfx++;
          }
          fpdlcqk9vm4xjosb++;
        }
      }
    }

    yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                   afpc0kns, &qfx3vhct, &yu6izdrc);

    yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                 t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                 &kvowz9ht, m0ibglfx, tlq9wpes, &yu6izdrc,
                 &dn3iasxug, &vsoihn1r, &pqneb2ra);

    wiptsjx8 = fabs(*tlq9wpes - *wkumc9idrpto5qwb) / (1.0e0 +
             fabs(*tlq9wpes));
    if (wiptsjx8 < bh2vgiay) { // xxx
      *zjkrtol8 = 0;
      xui7hqwl[7] = kcm6jfob;


      if (qfx3vhct == 3 || qfx3vhct == 5) {
        yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                     t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                     &kvowz9ht, m0ibglfx, tlq9wpes, &yu6izdrc,
                     &dn3iasxug, &vsoihn1r, &yu6izdrc);
      }
      x1jrewny = 1;
      goto ceqzd1hi20097;
    } else { // xxx and
      *wkumc9idrpto5qwb = *tlq9wpes;
      x1jrewny = 0;
    }
  }

  ceqzd1hi20097: hmayv1xt1 = 0.0e0;

  if (x1jrewny == 1) {
    Free(wkumc9idrpto5qwb);    Free(wkumc9idtwk);
    return;
  }

  if (f7svlajr == 1 || f7svlajr == 2) {
    f7svlajr = 0;
    xui7hqwl[8] = 1;
    goto ceqzd1hi653;
  }

  *zjkrtol8 = 3;

  Free(wkumc9idrpto5qwb);    Free(wkumc9idtwk);
}






void cqo_1(double lncwkfq7[], double tlgduey8[],
                double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[],
                double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[],
                double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                int *zjkrtol8, int xui7hqwl[],
                double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[]) {





  int    ayfnwr1v, hj3ftvzu, yu6izdrc = 0, pqneb2ra = 1, wr0lbopv,
         kcm6jfob, unhycz0e, xwdf5ltg, kvowz9ht, f7svlajr, qfx3vhct, c5aesxkul,
         ybnsqgo9, algpft4y, qemj9asg, xlpjcg3s, vtsou9pz, yru9olks;
  double dn3iasxug, wiptsjx8, pvofyg8z = 1.0e-7, uylxqtc7 = 0.0,
         bh2vgiay, uaf2xgqy, vsoihn1r, rsynp1go, rpto5qwb;
  double *fpdlcqk9zshtfg8c, *fpdlcqk9w8znmyce,
         *fpdlcqk9m0ibglfx,  *fpdlcqk9m0ibglfx1, *fpdlcqk9m0ibglfx2,
         *fpdlcqk9vm4xjosb,    *fpdlcqk9vc6hatuj,   *fpdlcqk9twk,
         *fpdlcqk9wpuarq2m,    *fpdlcqk9wpuarq2m1,   *fpdlcqk9wpuarq2m2,
         *fpdlcqk9ghz9vuba1,   *fpdlcqk9ghz9vuba2;



  int    gp1jxzuh;
  double hmayv1xt = 2.0, Totdev = 0.0e0;

  double *wkumc9idtwk;
  wkumc9idtwk    = Calloc(*br5ovgcj * 3  , double);

  xwdf5ltg    = xui7hqwl[0];
  xlpjcg3s   = xui7hqwl[2];
  kvowz9ht  = xui7hqwl[3];
  f7svlajr  = xui7hqwl[4];
  qfx3vhct = xui7hqwl[5];
  c5aesxkul  = xui7hqwl[6];
  xui7hqwl[8] = 0; // twice
  vtsou9pz = xui7hqwl[11];

  zjkrtol8[0] = -1;
  for (ayfnwr1v = 1; ayfnwr1v <= *afpc0kns; ayfnwr1v++)
    zjkrtol8[ayfnwr1v] = 1;

  if (vtsou9pz != 1) {
    Rprintf("Error: vtsou9pz is not unity in cqo_1!\n");
    *zjkrtol8 = 4;
    Free(wkumc9idtwk);
    return;
  }
  unhycz0e    = xui7hqwl[13];
  yru9olks    = xui7hqwl[15];
  wr0lbopv = xui7hqwl[17];    //20120222; correct but unused.

  dn3iasxug  = y7sdgtqi[0];
  uaf2xgqy = sqrt(dn3iasxug);
  if (qfx3vhct == 1 || qfx3vhct == 4)
      vsoihn1r = log(dn3iasxug);
  bh2vgiay   = y7sdgtqi[1];
  rsynp1go = y7sdgtqi[2];



  hmayv1xt  -= rsynp1go;
  hmayv1xt  += hmayv1xt;






  yiumjq3nflncwkfq71(lncwkfq7, w8znmyce, ftnjamu2, &xwdf5ltg,
                &qfx3vhct, vm4xjosb, br5ovgcj, &xlpjcg3s,
                kifxa0he, &yru9olks, &unhycz0e);

  
  
  
  
  

  for (hj3ftvzu = 1; hj3ftvzu <= *afpc0kns; hj3ftvzu++) {
    ceqzd1hi653: hmayv1xt = 1.0e0;

    if (f7svlajr == 0) {
      yiumjq3nietam6(tlgduey8, m0ibglfx, y7sdgtqi, ftnjamu2,
                   wy1vqfzu, afpc0kns, &qfx3vhct, &hj3ftvzu, ufgqj9ck, &wr0lbopv);

    } else
    if (f7svlajr == 2) {
      yiumjq3npkc4ejib(w8znmyce, zshtfg8c + (hj3ftvzu-1) * xlpjcg3s, m0ibglfx,
                   ftnjamu2, wy1vqfzu, br5ovgcj, &xlpjcg3s,
                   &vtsou9pz, &hj3ftvzu, &qfx3vhct, &unhycz0e,
                   vm4xjosb);
    }

    yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                  afpc0kns, &qfx3vhct, &hj3ftvzu);

    if (f7svlajr == 2) {
      yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                   t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                   &kvowz9ht, m0ibglfx, &rpto5qwb, &hj3ftvzu,
                   &dn3iasxug, &vsoihn1r, &pqneb2ra);
    } else {
      rpto5qwb = -1.0e0;
    }

    for (kcm6jfob = 1; kcm6jfob <= c5aesxkul; kcm6jfob++) {



      yiumjq3ndlgpwe0c(tlgduey8, ufgqj9ck, m0ibglfx,
                   t8hwvalr, ghz9vuba, rbne6ouj,
                   wpuarq2m, &rsynp1go, &dn3iasxug, &uaf2xgqy,
                   ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
                   &hj3ftvzu, &qfx3vhct, zjkrtol8 + hj3ftvzu, &unhycz0e, vm4xjosb);



      fpdlcqk9vc6hatuj = vc6hatuj; fpdlcqk9w8znmyce = w8znmyce;
      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++)
        for (ayfnwr1v = 1; ayfnwr1v <= *br5ovgcj; ayfnwr1v++)
           *fpdlcqk9vc6hatuj++ = *fpdlcqk9w8znmyce++;

      if (qfx3vhct == 3 || qfx3vhct == 5) {
        if (2 * *ftnjamu2 != *br5ovgcj)  //Rprintf
          Rprintf("Error: 2 * *ftnjamu2 != *br5ovgcj in C_cqo_1\n");
        fpdlcqk9vc6hatuj = vc6hatuj;
        for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
          fpdlcqk9wpuarq2m2 = wpuarq2m + 2*hj3ftvzu -2;
          fpdlcqk9wpuarq2m1 = wpuarq2m + 2*hj3ftvzu -1;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9vc6hatuj *= *fpdlcqk9wpuarq2m2;
             fpdlcqk9vc6hatuj++;
            *fpdlcqk9vc6hatuj *= *fpdlcqk9wpuarq2m1;
             fpdlcqk9vc6hatuj++;
             fpdlcqk9wpuarq2m1 += *npjlv3mr;
             fpdlcqk9wpuarq2m2 += *npjlv3mr;
          }
        }
      } else {
        if (1 * *ftnjamu2 != *br5ovgcj)  //Rprintf
          Rprintf("Error: 1 * *ftnjamu2 != *br5ovgcj in C_cqo_1\n");
        fpdlcqk9vc6hatuj = vc6hatuj;
        for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
          fpdlcqk9wpuarq2m = wpuarq2m + hj3ftvzu -1;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9vc6hatuj *= *fpdlcqk9wpuarq2m;
             fpdlcqk9vc6hatuj++;
             fpdlcqk9wpuarq2m  += *npjlv3mr;
          }
        }
      }

      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++)
        ges1xpkr[gp1jxzuh-1] = gp1jxzuh;


      F77_CALL(vqrdca)(vc6hatuj, br5ovgcj, br5ovgcj, &xlpjcg3s, fasrkub3, ges1xpkr,
                       wkumc9idtwk, &qemj9asg, &pvofyg8z);

      if (qemj9asg != xlpjcg3s) {
        Rprintf("Error in cqo_1: vc6hatuj is not of full xwdf5ltg.\n");
        *zjkrtol8 = 2;
        Free(wkumc9idtwk);
        return;
      }

      if (qfx3vhct == 3 || qfx3vhct == 5) {
        fpdlcqk9ghz9vuba1 = ghz9vuba + (2*hj3ftvzu-1) * *ftnjamu2;
        fpdlcqk9ghz9vuba2 = ghz9vuba + (2*hj3ftvzu-2) * *ftnjamu2;
        fpdlcqk9wpuarq2m1 = wpuarq2m +  2*hj3ftvzu-1;
        fpdlcqk9wpuarq2m2 = wpuarq2m +  2*hj3ftvzu-2;
        fpdlcqk9twk   = wkumc9idtwk;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9twk++ = *fpdlcqk9wpuarq2m2 * *fpdlcqk9ghz9vuba2++;
          *fpdlcqk9twk++ = *fpdlcqk9wpuarq2m1 * *fpdlcqk9ghz9vuba1++;
          fpdlcqk9wpuarq2m1 += *npjlv3mr;
          fpdlcqk9wpuarq2m2 += *npjlv3mr;
        }
      } else {
        fpdlcqk9ghz9vuba1 = ghz9vuba + (hj3ftvzu-1) * *ftnjamu2;
        fpdlcqk9twk   = wkumc9idtwk;
        fpdlcqk9wpuarq2m  = wpuarq2m + hj3ftvzu-1;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9twk++ = *fpdlcqk9wpuarq2m * *fpdlcqk9ghz9vuba1++;
          fpdlcqk9wpuarq2m  += *npjlv3mr;
        }
      }

      ybnsqgo9 = 101;

      F77_CALL(vdqrsl)(vc6hatuj, br5ovgcj, br5ovgcj, &qemj9asg, fasrkub3, wkumc9idtwk,
                       &uylxqtc7, wkumc9idtwk + *br5ovgcj,
                       zshtfg8c + (hj3ftvzu-1) * xlpjcg3s,
                       &uylxqtc7, wkumc9idtwk + 2 * *br5ovgcj, &ybnsqgo9, &algpft4y);


      fpdlcqk9twk     = wkumc9idtwk;
      fpdlcqk9zshtfg8c = zshtfg8c + (hj3ftvzu-1) * xlpjcg3s;
      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
        *fpdlcqk9twk++ = *fpdlcqk9zshtfg8c++;
      }

      fpdlcqk9twk     = wkumc9idtwk;
      fpdlcqk9zshtfg8c = zshtfg8c + (hj3ftvzu-1) * xlpjcg3s;
      for (gp1jxzuh = 1; gp1jxzuh <= xlpjcg3s; gp1jxzuh++) {
        *(fpdlcqk9zshtfg8c + ges1xpkr[gp1jxzuh-1] - 1) = *fpdlcqk9twk++;
      }

      if (qfx3vhct == 3 || qfx3vhct == 5) {

        fpdlcqk9m0ibglfx2 = m0ibglfx   + 2 * hj3ftvzu -2;
        fpdlcqk9m0ibglfx1 = m0ibglfx   + 2 * hj3ftvzu -1;
        fpdlcqk9twk     = wkumc9idtwk + 2 * *br5ovgcj;
        fpdlcqk9wpuarq2m2   = wpuarq2m     + 2 * hj3ftvzu -2;
        fpdlcqk9wpuarq2m1   = wpuarq2m     + 2 * hj3ftvzu -1;

        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9m0ibglfx2  = *fpdlcqk9twk++ / *fpdlcqk9wpuarq2m2;
          *fpdlcqk9m0ibglfx1  = *fpdlcqk9twk++ / *fpdlcqk9wpuarq2m1;
           fpdlcqk9m0ibglfx1 += *wy1vqfzu;
           fpdlcqk9m0ibglfx2 += *wy1vqfzu;
           fpdlcqk9wpuarq2m1   += *npjlv3mr;
           fpdlcqk9wpuarq2m2   += *npjlv3mr;
        }

        if (unhycz0e == 1) {
          fpdlcqk9m0ibglfx = m0ibglfx + 2*hj3ftvzu-2;
          fpdlcqk9vm4xjosb   = vm4xjosb;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb++;
             fpdlcqk9m0ibglfx += *wy1vqfzu;
          }
        }
      } else {
        fpdlcqk9m0ibglfx  = m0ibglfx   +     hj3ftvzu -1;
        fpdlcqk9twk     = wkumc9idtwk + 2 * *br5ovgcj;
        fpdlcqk9wpuarq2m    = wpuarq2m     +     hj3ftvzu -1;

        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          *fpdlcqk9m0ibglfx   = *fpdlcqk9twk++ / *fpdlcqk9wpuarq2m;
           fpdlcqk9m0ibglfx  += *wy1vqfzu;
           fpdlcqk9wpuarq2m    += *npjlv3mr;
        }
        if (unhycz0e == 1) {
          fpdlcqk9m0ibglfx = m0ibglfx +   hj3ftvzu-1;
          fpdlcqk9vm4xjosb   = vm4xjosb;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9m0ibglfx += *fpdlcqk9vm4xjosb++;
             fpdlcqk9m0ibglfx += *wy1vqfzu;
          }
        }
      }

      yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                    afpc0kns, &qfx3vhct, &hj3ftvzu);

      yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                   t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                   &kvowz9ht, m0ibglfx, tlq9wpes + hj3ftvzu, &hj3ftvzu,
                   &dn3iasxug, &vsoihn1r, &pqneb2ra);

      wiptsjx8 = fabs(tlq9wpes[hj3ftvzu] - rpto5qwb) / (1.0e0 +
               fabs(tlq9wpes[hj3ftvzu]));
      if (wiptsjx8 < bh2vgiay) {
        zjkrtol8[hj3ftvzu] = 0;
        xui7hqwl[7] = kcm6jfob;
        if (qfx3vhct == 3 || qfx3vhct == 5) {
          yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                       t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                       &kvowz9ht, m0ibglfx, tlq9wpes + hj3ftvzu, &hj3ftvzu,
                       &dn3iasxug, &vsoihn1r, &yu6izdrc);
        }
        Totdev += tlq9wpes[hj3ftvzu];
        goto ceqzd1hi1011;
      } else {
        rpto5qwb = tlq9wpes[hj3ftvzu];
      }
    }

    Rprintf("cqo_1; no convergence for Species ");
    Rprintf("number %3d. Trying internal starting values.\n", hj3ftvzu);
    if (f7svlajr == 1) {
      f7svlajr = 0;
      xui7hqwl[8] = 1;
      goto ceqzd1hi653;
    }

    *zjkrtol8 = 3;
     zjkrtol8[hj3ftvzu] = 2;
    Rprintf("cqo_1; no convergence for Species ");
    Rprintf("number %3d. Continuing on with other species.\n", hj3ftvzu);
    Totdev += tlq9wpes[hj3ftvzu];

  ceqzd1hi1011: hmayv1xt = 3.0e0;
  }


  if (zjkrtol8[0] == -1)
    for (ayfnwr1v = 1; ayfnwr1v <= *afpc0kns; ayfnwr1v++)
      if (zjkrtol8[ayfnwr1v] != 0) zjkrtol8[0] = 1;
  if (zjkrtol8[0] == -1)
      zjkrtol8[0] = 0;

  *tlq9wpes = Totdev;

  Free(wkumc9idtwk);
}





void dcqo1(double lncwkfq7[], double tlgduey8[], double kifxa0he[],
                double ufgqj9ck[], double m0ibglfx[], double vm4xjosb[],
                double t8hwvalr[], double ghz9vuba[], double rbne6ouj[],
                double wpuarq2m[], double w8znmyce[], double vc6hatuj[],
                double fasrkub3[], int ges1xpkr[],
                int *ftnjamu2, int *wy1vqfzu,
                int *afpc0kns, int *br5ovgcj, int *npjlv3mr, int *zjkrtol8,
                int xui7hqwl[], double *tlq9wpes, double zshtfg8c[],
                double y7sdgtqi[],
                double atujnxb8[],
                double k7hulceq[], int *eoviz2fb,
                double kpzavbj3mat[], double *ydcnh9xl) {





  int    ayfnwr1v, gp1jxzuh,  xvr7bonh, hpmwnav2, idlosrw8, xwdf5ltg = xui7hqwl[ 0],
         vtsou9pz;
  int    exrkcn5d = xui7hqwl[12];
  double fxnhilr3,          *fpdlcqk9k7hulceq,
         *fpdlcqk9kpzavbj3mat, *fpdlcqk9lncwkfq7,  *fpdlcqk9yxiwebc5, *fpdlcqk9atujnxb8;

  double *wkumc9idajul8wkv, *wkumc9iddev0,   *wkumc9idyxiwebc5;
  wkumc9idajul8wkv = Calloc(exrkcn5d         , double);
  wkumc9iddev0     = Calloc(1 + *afpc0kns        , double);
  wkumc9idyxiwebc5   = Calloc(*ftnjamu2 * xwdf5ltg    , double);

  fpdlcqk9kpzavbj3mat = kpzavbj3mat;


  idlosrw8 = xui7hqwl[ 4];
  vtsou9pz  = xui7hqwl[11];

  fpdlcqk9lncwkfq7   = lncwkfq7;
  fpdlcqk9yxiwebc5  = wkumc9idyxiwebc5;
  for (hpmwnav2 = 1; hpmwnav2 <= xwdf5ltg; hpmwnav2++) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      fxnhilr3 = 0.0e0;
      fpdlcqk9k7hulceq   = k7hulceq + (hpmwnav2-1) * *eoviz2fb;
      fpdlcqk9atujnxb8  = atujnxb8 + ayfnwr1v-1;
      for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
        fxnhilr3      += *fpdlcqk9atujnxb8 * *fpdlcqk9k7hulceq++;
        fpdlcqk9atujnxb8 += *ftnjamu2;
      }
      *fpdlcqk9yxiwebc5++ = *fpdlcqk9lncwkfq7++ = fxnhilr3;
    }
  }
  if (vtsou9pz == 1) {
    cqo_1(lncwkfq7, tlgduey8, kifxa0he, ufgqj9ck,
          m0ibglfx, vm4xjosb, t8hwvalr, ghz9vuba, rbne6ouj, wpuarq2m, w8znmyce,
          vc6hatuj, fasrkub3, ges1xpkr,
          ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
          zjkrtol8, xui7hqwl, wkumc9iddev0, wkumc9idajul8wkv, y7sdgtqi);

  } else {
    cqo_2(lncwkfq7, tlgduey8, kifxa0he, ufgqj9ck,
          m0ibglfx, vm4xjosb, t8hwvalr, ghz9vuba, rbne6ouj, wpuarq2m, w8znmyce,
          vc6hatuj, fasrkub3, ges1xpkr,
          ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
          zjkrtol8, xui7hqwl, wkumc9iddev0, wkumc9idajul8wkv, y7sdgtqi);
  }


  fpdlcqk9atujnxb8 = atujnxb8;
  for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9atujnxb8 *= *ydcnh9xl;
       fpdlcqk9atujnxb8++;
    }
  }

  for (hpmwnav2 = 1; hpmwnav2 <= xwdf5ltg; hpmwnav2++) {
    for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
          fpdlcqk9lncwkfq7  =       lncwkfq7  + (hpmwnav2-1) * *ftnjamu2;
          fpdlcqk9yxiwebc5 = wkumc9idyxiwebc5  + (hpmwnav2-1) * *ftnjamu2;
          fpdlcqk9atujnxb8  =       atujnxb8  + (xvr7bonh-1) * *ftnjamu2;
          for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
            *fpdlcqk9lncwkfq7++ = *fpdlcqk9yxiwebc5++ + *fpdlcqk9atujnxb8++;
          }


      xui7hqwl[4] = 2;

      for (gp1jxzuh = 1; gp1jxzuh <= exrkcn5d; gp1jxzuh++)
        zshtfg8c[gp1jxzuh-1] = wkumc9idajul8wkv[gp1jxzuh-1];

      if (vtsou9pz == 1) {
        cqo_1(lncwkfq7, tlgduey8, kifxa0he, ufgqj9ck,
              m0ibglfx, vm4xjosb, t8hwvalr, ghz9vuba, rbne6ouj, wpuarq2m, w8znmyce,
              vc6hatuj, fasrkub3, ges1xpkr,
              ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
              zjkrtol8, xui7hqwl,
              tlq9wpes, zshtfg8c, y7sdgtqi);
      } else {
        cqo_2(lncwkfq7, tlgduey8, kifxa0he, ufgqj9ck,
              m0ibglfx, vm4xjosb, t8hwvalr, ghz9vuba, rbne6ouj, wpuarq2m, w8znmyce,
              vc6hatuj, fasrkub3, ges1xpkr,
              ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
              zjkrtol8, xui7hqwl,
              tlq9wpes, zshtfg8c, y7sdgtqi);
      }

      if (*zjkrtol8 != 0) {
        Rprintf("Error in dcqo1: zjkrtol8 = %d\n", *zjkrtol8);
        Rprintf("Continuing.\n");
      }
      *fpdlcqk9kpzavbj3mat++ = (*tlq9wpes - *wkumc9iddev0) / *ydcnh9xl;
    }

    if (xwdf5ltg > 1) {
      fpdlcqk9lncwkfq7  =        lncwkfq7 + (hpmwnav2-1) * *ftnjamu2;
      fpdlcqk9yxiwebc5 =  wkumc9idyxiwebc5 + (hpmwnav2-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
         *fpdlcqk9lncwkfq7++  = *fpdlcqk9yxiwebc5++;
    }
  }

  Free(wkumc9idajul8wkv);   Free(wkumc9iddev0);   Free(wkumc9idyxiwebc5);

  xui7hqwl[4] = idlosrw8;
}








void vcao6(double lncwkfq7[], double tlgduey8[], double ufgqj9ck[],
           double m0ibglfx[], double t8hwvalr[], double ghz9vuba[],
           double rbne6ouj[], double wpuarq2m[],
           double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
           int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
           int *zjkrtol8, int xui7hqwl[],
           double tlq9wpes[], double zshtfg8c[],
           double y7sdgtqi[], int psdvgce3[], int *qfozcl5b,
           double hdnw2fts[], double lamvec[], double wbkq9zyi[],
           int ezlgm2up[], int lqsahu0r[], int which[],
           double kispwgx3[],
           double mbvnaor6[],
           double hjm2ktyr[],
           int jnxpuym2[], int hnpt1zym[], int iz2nbfjc[],
           double ifys6woa[], double rpyis2kc[], double gkdx5jals[],
           int nbzjkpi3[], int lindex[],
           int acpios9q[], int jwbkl9fp[]) {





  int    hj3ftvzu, ehtjigf4, kvowz9ht,
         yu6izdrc = 0, pqneb2ra = 1, xwdf5ltg = xui7hqwl[0],
         f7svlajr, qfx3vhct, c5aesxkul, wr0lbopv, vtsou9pz, xlpjcg3s,
         sedf7mxb, kcm6jfob, lensmo = (xwdf5ltg == 1 ? 2 : 4) * *afpc0kns;
  double rpto5qwb, dn3iasxug, wiptsjx8, bh2vgiay, uaf2xgqy, vsoihn1r,
         rsynp1go, fjcasv7g[6], ghdetj8v = 0.0;
  double *fpdlcqk9kispwgx3;


  int    len_1spp_ifys6woa;


  double hmayv1xt = 0.0, Totdev = 0.0e0;




  int    qes4mujl, ayfnwr1v, kij0gwer, xumj5dnk, lyma1kwc; // = xui7hqwl[10];

  double  hmayv1xtvm4xjosb[2];

  double *fpdlcqk9lxyst1eb, *fpdlcqk9zyodca3j,
         *fpdlcqk9m0ibglfx1, *fpdlcqk9m0ibglfx2, *fpdlcqk9wpuarq2m1, *fpdlcqk9wpuarq2m2;
  double *wkumc9idui8ysltq,  *wkumc9idlxyst1eb, *wkumc9idzyodca3j;
  double *wkumc9idhdnw2fts,  *wkumc9idwbkq9zyi;


  fjcasv7g[0] =  0.001;
  fjcasv7g[1] =  0.0;
  fjcasv7g[2] = -1.5;
  fjcasv7g[3] =  1.5;
  fjcasv7g[4] =  1.0e-4;
  fjcasv7g[5] =  2.0e-8;

  wkumc9idui8ysltq  = Calloc((*ftnjamu2 * *wy1vqfzu) * (*afpc0kns * *wy1vqfzu), double);
  wkumc9idlxyst1eb = Calloc( *qfozcl5b * *ftnjamu2                , double);
  wkumc9idzyodca3j    = Calloc( *qfozcl5b * *ftnjamu2                , double);
  wkumc9idhdnw2fts  = Calloc(lensmo                        , double);
  wkumc9idwbkq9zyi  = Calloc(lensmo                        , double);

  for (ayfnwr1v = 0; ayfnwr1v < lensmo; ayfnwr1v++) {
    wkumc9idhdnw2fts[ayfnwr1v] = hdnw2fts[ayfnwr1v];
    wkumc9idwbkq9zyi[ayfnwr1v] = wbkq9zyi[ayfnwr1v];
  }


  xlpjcg3s   = xui7hqwl[2];
  kvowz9ht  = xui7hqwl[3];  // # = 1
  f7svlajr  = xui7hqwl[4];
  qfx3vhct = xui7hqwl[5];
  c5aesxkul  = xui7hqwl[6];
  xui7hqwl[8] = 0;

  lyma1kwc   = psdvgce3[10]; //

  vtsou9pz = xui7hqwl[11];
  if (vtsou9pz != 1 || lyma1kwc != xwdf5ltg) {
    Rprintf("Error: 'vtsou9pz' != 1, or 'lyma1kwc' != 'xwdf5ltg', in vcao6!\n");
    *zjkrtol8 = 4;
    Free(wkumc9idui8ysltq);    Free(wkumc9idlxyst1eb);   Free(wkumc9idzyodca3j);
    Free(wkumc9idhdnw2fts);    Free(wkumc9idwbkq9zyi);
    return;
  }
  wr0lbopv = xui7hqwl[17];
  dn3iasxug  = y7sdgtqi[0];
  uaf2xgqy = sqrt(dn3iasxug);
  vsoihn1r = log(dn3iasxug);
  bh2vgiay   = y7sdgtqi[1];
  rsynp1go = y7sdgtqi[2];



  hmayv1xt += hmayv1xt;
  hmayv1xt *= hmayv1xt;




  len_1spp_ifys6woa = lindex[lyma1kwc] - 1;






  *zjkrtol8 = 1;

  for (hj3ftvzu = 1; hj3ftvzu <= *afpc0kns; hj3ftvzu++) {
    ceqzd1hi653:  hmayv1xt = 1.0;

    qes4mujl = (qfx3vhct == 3 || qfx3vhct == 5) ?  2 * hj3ftvzu - 1 : hj3ftvzu;

    if (f7svlajr == 0) {
      yiumjq3nietam6(tlgduey8, m0ibglfx, y7sdgtqi, ftnjamu2,
                   wy1vqfzu, afpc0kns, &qfx3vhct, &hj3ftvzu, ufgqj9ck, &wr0lbopv);
    } else
    if (f7svlajr != 1) {
      Rprintf("Failure due to bad input of 'f7svlajr' variable\n");
      *zjkrtol8 = 6;
      Free(wkumc9idui8ysltq);    Free(wkumc9idlxyst1eb);   Free(wkumc9idzyodca3j);
      Free(wkumc9idhdnw2fts);    Free(wkumc9idwbkq9zyi);
      return;
    }

    yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                  afpc0kns, &qfx3vhct, &hj3ftvzu);

    if (f7svlajr == 2) {
      yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                   t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                   &kvowz9ht, m0ibglfx, &rpto5qwb, &hj3ftvzu,
                   &dn3iasxug, &vsoihn1r, &pqneb2ra);
    } else {
      rpto5qwb = -1.0e0;
    }

    for (kcm6jfob = 1; kcm6jfob <= c5aesxkul; kcm6jfob++) {

      yiumjq3nflncwkfq76(lncwkfq7, vc6hatuj, ftnjamu2, br5ovgcj, &xwdf5ltg, &qfx3vhct);

      psdvgce3[6] = 0;

      yiumjq3ndlgpwe0c(tlgduey8, ufgqj9ck, m0ibglfx,
                   t8hwvalr, ghz9vuba, rbne6ouj,
                   wpuarq2m, &rsynp1go, &dn3iasxug, &uaf2xgqy,
                   ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
                   &hj3ftvzu, &qfx3vhct, zjkrtol8, &yu6izdrc, hmayv1xtvm4xjosb);


      fpdlcqk9lxyst1eb = wkumc9idlxyst1eb;
      fpdlcqk9zyodca3j    = wkumc9idzyodca3j;
      fpdlcqk9m0ibglfx1 =  m0ibglfx + qes4mujl-1;
      fpdlcqk9wpuarq2m1   =    wpuarq2m + qes4mujl-1;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        fpdlcqk9m0ibglfx2 = fpdlcqk9m0ibglfx1;
        fpdlcqk9wpuarq2m2   = fpdlcqk9wpuarq2m1;
        for (kij0gwer = 1; kij0gwer <= *qfozcl5b; kij0gwer++) {
          *fpdlcqk9lxyst1eb++ = *fpdlcqk9m0ibglfx2++;
          *fpdlcqk9zyodca3j++    = *fpdlcqk9wpuarq2m2++;
        }
        fpdlcqk9m0ibglfx1 += *wy1vqfzu;
        fpdlcqk9wpuarq2m1   += *npjlv3mr;
      }



        sedf7mxb = 0; // 20100416 a stop gap. Used for xwdf5ltg==2 only i think.
        ehtjigf4 = xwdf5ltg * (hj3ftvzu-1);

        if (kcm6jfob == 1) {
          for (kij0gwer = 1; kij0gwer <= lyma1kwc; kij0gwer++) {
            fpdlcqk9kispwgx3 = kispwgx3 + (ehtjigf4 + hnpt1zym[kij0gwer-1]-1) * *ftnjamu2;
            for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
              *fpdlcqk9kispwgx3++ = 0.0e0;
          }
        } else {
                 wbkq9zyi[       ehtjigf4 + hnpt1zym[0]-1] =
            wkumc9idwbkq9zyi[       ehtjigf4 + hnpt1zym[0]-1];
                 hdnw2fts[       ehtjigf4 + hnpt1zym[0]-1] =
            wkumc9idhdnw2fts[       ehtjigf4 + hnpt1zym[0]-1];
          if (xwdf5ltg == 2) {
                 wbkq9zyi[       ehtjigf4 + hnpt1zym[1]-1] =
            wkumc9idwbkq9zyi[       ehtjigf4 + hnpt1zym[1]-1]; // wkumc9idr3eoxkzp;
                 hdnw2fts[sedf7mxb + ehtjigf4 + hnpt1zym[1]-1] =
            wkumc9idhdnw2fts[sedf7mxb + ehtjigf4 + hnpt1zym[1]-1]; // wkumc9idwld4qctn;
          }
        }

        Yee_vbfa(psdvgce3, fjcasv7g,
                        mbvnaor6, ghz9vuba + (qes4mujl-1) * *ftnjamu2,
                 rbne6ouj + (qes4mujl-1) * *ftnjamu2,
                        hdnw2fts + sedf7mxb + ehtjigf4 + hnpt1zym[0] - 1,
                        lamvec +        ehtjigf4 + hnpt1zym[0] - 1,
                        wbkq9zyi +        ehtjigf4 + hnpt1zym[0] - 1,
                 ezlgm2up, lqsahu0r, which,
                 kispwgx3 + (ehtjigf4 + *hnpt1zym - 1) * *ftnjamu2, wkumc9idlxyst1eb,
                 zshtfg8c + (hj3ftvzu - 1) * xlpjcg3s, wkumc9idui8ysltq,
                 vc6hatuj, fasrkub3, ges1xpkr,
                 wkumc9idzyodca3j, hjm2ktyr,
                 jnxpuym2, hnpt1zym, iz2nbfjc,




                 ifys6woa + ehtjigf4 * len_1spp_ifys6woa,



                 rpyis2kc + (hj3ftvzu-1) * (nbzjkpi3[xwdf5ltg] - 1), gkdx5jals,
                 nbzjkpi3, lindex,  // 20130525; lindex added
                 acpios9q, jwbkl9fp);




        y7sdgtqi[3 + *afpc0kns + *afpc0kns] = ghdetj8v;
        xumj5dnk = psdvgce3[13];
        if (xumj5dnk != 0) {
          Rprintf("vcao6: Error... exiting; error code = %d\n", xumj5dnk);
          *zjkrtol8 = 8;
          Free(wkumc9idui8ysltq);    Free(wkumc9idlxyst1eb);   Free(wkumc9idzyodca3j);
          Free(wkumc9idhdnw2fts);    Free(wkumc9idwbkq9zyi);
          return;
        }

        fpdlcqk9lxyst1eb = wkumc9idlxyst1eb;
        fpdlcqk9m0ibglfx1 =       m0ibglfx + qes4mujl-1;
        for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
          fpdlcqk9m0ibglfx2 = fpdlcqk9m0ibglfx1;
          for (kij0gwer = 1; kij0gwer <= *qfozcl5b; kij0gwer++) {
            *fpdlcqk9m0ibglfx2++ = *fpdlcqk9lxyst1eb++;
          }
          fpdlcqk9m0ibglfx1 += *wy1vqfzu;
        }

        yiumjq3nnipyajc1(m0ibglfx, t8hwvalr, ftnjamu2, wy1vqfzu,
                      afpc0kns, &qfx3vhct, &hj3ftvzu);

        yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                     t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                     &kvowz9ht, m0ibglfx, tlq9wpes + hj3ftvzu, &hj3ftvzu,
                     &dn3iasxug, &vsoihn1r, &pqneb2ra);

      wiptsjx8 = fabs(tlq9wpes[hj3ftvzu] - rpto5qwb) / (1.0e0 +
               fabs(tlq9wpes[hj3ftvzu]));

      if (wiptsjx8 < bh2vgiay) {
        *zjkrtol8 = 0;
        xui7hqwl[7] = kcm6jfob;
        if (qfx3vhct == 3 || qfx3vhct == 5) {
          yiumjq3nshjlwft5(&qfx3vhct, tlgduey8, ufgqj9ck,
                       t8hwvalr, ftnjamu2, wy1vqfzu, afpc0kns,
                       &kvowz9ht, m0ibglfx, tlq9wpes + hj3ftvzu, &hj3ftvzu,
                       &dn3iasxug, &vsoihn1r, &yu6izdrc);
        }
        Totdev += tlq9wpes[hj3ftvzu];
        goto ceqzd1hi1011;
      } else {
        rpto5qwb = tlq9wpes[hj3ftvzu];
      }
    }

    if (f7svlajr == 1) {
      f7svlajr = 0;
      xui7hqwl[8] = 1;
      goto ceqzd1hi653;
    }

    *zjkrtol8 = 3;
    Totdev += tlq9wpes[hj3ftvzu];

  ceqzd1hi1011: hmayv1xt = 2.0e0;
  }

  *tlq9wpes = Totdev;
  Free(wkumc9idui8ysltq);    Free(wkumc9idlxyst1eb);   Free(wkumc9idzyodca3j);
  Free(wkumc9idhdnw2fts);    Free(wkumc9idwbkq9zyi);
}








void vdcao6(double lncwkfq7[], double tlgduey8[], double ufgqj9ck[],
                  double m0ibglfx[], double t8hwvalr[], double ghz9vuba[],
                  double rbne6ouj[], double wpuarq2m[],
                  double vc6hatuj[], double fasrkub3[], int ges1xpkr[],
                  int *ftnjamu2, int *wy1vqfzu, int *afpc0kns, int *br5ovgcj, int *npjlv3mr,
                  int *zjkrtol8, int xui7hqwl[],
                  double tlq9wpes[], double zshtfg8c[],
                  double y7sdgtqi[],
                  double atujnxb8[],
                  double k7hulceq[],
                  int *eoviz2fb, double kpzavbj3mat[],
                  double ajul8wkv[],
                  int psdvgce3[], int *qfozcl5b,
                  double hdnw2fts[], double lamvec[], double wbkq9zyi[],
                  int ezlgm2up[], int lqsahu0r[], int which[],
                  double kispwgx3[],
                  double mbvnaor6[],
                  double hjm2ktyr[],
                  int jnxpuym2[], int hnpt1zym[],
                  int iz2nbfjc[],
                  double ifys6woa[],
                  double rpyis2kc[], double gkdx5jals[],
                  int nbzjkpi3[], int lindex[],
                  int acpios9q[], int jwbkl9fp[]) {




  int    ayfnwr1v, xvr7bonh, hpmwnav2, idlosrw8, xwdf5ltg = xui7hqwl[ 0],
         vtsou9pz;
  double fxnhilr3;




  double ghdetj8v = 0.0e0, ydcnh9xl = y7sdgtqi[3 + *afpc0kns + *afpc0kns + 3 -1];
  double *fpdlcqk9k7hulceq, *fpdlcqk9kpzavbj3mat, *fpdlcqk9lncwkfq7, *fpdlcqk9yxiwebc5,
         *fpdlcqk9atujnxb8;

  double *wkumc9idyxiwebc5;
  double *wkumc9idlxyst1eb, *wkumc9idzyodca3j;
  double *wkumc9iddev0;

  wkumc9idyxiwebc5   = Calloc(*ftnjamu2 * xwdf5ltg    , double);
  fpdlcqk9kpzavbj3mat = kpzavbj3mat;

  wkumc9iddev0    = Calloc(1 + *afpc0kns         , double);
  wkumc9idlxyst1eb = Calloc( *qfozcl5b * *ftnjamu2   , double);
  wkumc9idzyodca3j    = Calloc( *qfozcl5b * *ftnjamu2   , double);

  idlosrw8 = xui7hqwl[ 4];
  vtsou9pz  = xui7hqwl[11];



  fpdlcqk9lncwkfq7   = lncwkfq7;
  fpdlcqk9yxiwebc5  = wkumc9idyxiwebc5;
  for (hpmwnav2 = 1; hpmwnav2 <= xwdf5ltg; hpmwnav2++) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      fxnhilr3 = 0.0e0;
      fpdlcqk9k7hulceq   = k7hulceq + (hpmwnav2-1) * *eoviz2fb;
      fpdlcqk9atujnxb8  = atujnxb8 + ayfnwr1v-1;
      for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
        fxnhilr3      += *fpdlcqk9atujnxb8 * *fpdlcqk9k7hulceq++;
        fpdlcqk9atujnxb8 += *ftnjamu2;
      }
      *fpdlcqk9yxiwebc5++ = *fpdlcqk9lncwkfq7++ = fxnhilr3;
    }
  }

  if (vtsou9pz == 1) {
    vcao6(lncwkfq7, tlgduey8, ufgqj9ck,
          m0ibglfx, t8hwvalr, ghz9vuba,
          rbne6ouj, wpuarq2m,
          vc6hatuj, fasrkub3, ges1xpkr,
          ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
          zjkrtol8, xui7hqwl,
          wkumc9iddev0, ajul8wkv,
          y7sdgtqi, psdvgce3, qfozcl5b,
          hdnw2fts, lamvec, wbkq9zyi,
          ezlgm2up, lqsahu0r, which,
          kispwgx3,
          mbvnaor6,
          hjm2ktyr,
          jnxpuym2, hnpt1zym, iz2nbfjc,
          ifys6woa, rpyis2kc, gkdx5jals,
          nbzjkpi3, lindex,
          acpios9q, jwbkl9fp);

    y7sdgtqi[3 + *afpc0kns + *afpc0kns] = ghdetj8v;
  }

  fpdlcqk9atujnxb8 = atujnxb8;
  for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
    for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
      *fpdlcqk9atujnxb8 *= ydcnh9xl;
       fpdlcqk9atujnxb8++;
    }
  }

  for (hpmwnav2 = 1; hpmwnav2 <= xwdf5ltg; hpmwnav2++) {
    fpdlcqk9atujnxb8  =  atujnxb8;  //  + (xvr7bonh-1) * *ftnjamu2;
    for (xvr7bonh = 1; xvr7bonh <= *eoviz2fb; xvr7bonh++) {
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++) {
        *fpdlcqk9lncwkfq7++ = *fpdlcqk9yxiwebc5++ +  *fpdlcqk9atujnxb8++;
      }
      xui7hqwl[4] = 0;


      if (vtsou9pz == 1) {
        vcao6(lncwkfq7, tlgduey8, ufgqj9ck,
              m0ibglfx, t8hwvalr, ghz9vuba,
              rbne6ouj, wpuarq2m,
              vc6hatuj, fasrkub3, ges1xpkr,
              ftnjamu2, wy1vqfzu, afpc0kns, br5ovgcj, npjlv3mr,
              zjkrtol8, xui7hqwl,
              tlq9wpes, zshtfg8c,
              y7sdgtqi, psdvgce3, qfozcl5b,
              hdnw2fts, lamvec, wbkq9zyi,
              ezlgm2up, lqsahu0r, which,
              kispwgx3,
              mbvnaor6,
              hjm2ktyr,
              jnxpuym2, hnpt1zym, iz2nbfjc,
              ifys6woa, rpyis2kc, gkdx5jals,
              nbzjkpi3, lindex,
              acpios9q, jwbkl9fp);

        y7sdgtqi[3 + *afpc0kns + *afpc0kns] = ghdetj8v;
      }

      if (*zjkrtol8 != 0) {
        Rprintf("Warning: failured to converge in vdcao6. \n");
        Rprintf("Continuing.\n");
      }
      *fpdlcqk9kpzavbj3mat++ = (*tlq9wpes - *wkumc9iddev0) / ydcnh9xl;
    }

    if (xwdf5ltg > 1) {
      fpdlcqk9lncwkfq7  =       lncwkfq7 + (hpmwnav2-1) * *ftnjamu2;
      fpdlcqk9yxiwebc5 = wkumc9idyxiwebc5 + (hpmwnav2-1) * *ftnjamu2;
      for (ayfnwr1v = 1; ayfnwr1v <= *ftnjamu2; ayfnwr1v++)
        *fpdlcqk9lncwkfq7++ = *fpdlcqk9yxiwebc5++;
    }
  }

  Free(wkumc9idyxiwebc5);    Free(wkumc9iddev0 );
  Free(wkumc9idlxyst1eb);   Free(wkumc9idzyodca3j);

  xui7hqwl[4] = idlosrw8;
}


void yiumjq3npnm1or(double *objzgdk0, double *lfu2qhid) {

  int    sn;
  double R1, R2, y, y2, y3, y4, y5, y6, y7;
  double erf, erfc, z, z2, z3, z4;


  double
  SQRT2  = 1.414213562373095049e0,
  SQRTPI = 1.772453850905516027e0,


  ULIMIT = 20.0e0,

  P10 = 242.66795523053175e0,
  P11 = 21.979261618294152e0,
  P12 = 6.9963834886191355e0,
  P13 = -.035609843701815385e0,
  Q10 = 215.05887586986120e0,
  Q11 = 91.164905404514901e0,
  Q12 = 15.082797630407787e0,
  Q13 = 1.0e0,

  P20 = 300.4592610201616005e0,
  P21 = 451.9189537118729422e0,
  P22 = 339.3208167343436870e0,
  P23 = 152.9892850469404039e0,
  P24 = 43.16222722205673530e0,
  P25 = 7.211758250883093659e0,
  P26 = .5641955174789739711e0,
  P27 = -.0000001368648573827167067e0,
  Q20 = 300.4592609569832933e0,
  Q21 = 790.9509253278980272e0,
  Q22 = 931.3540948506096211e0,
  Q23 = 638.9802644656311665e0,
  Q24 = 277.5854447439876434e0,
  Q25 = 77.00015293522947295e0,
  Q26 = 12.78272731962942351e0,
  Q27 = 1.0e0,

  P30 = -.00299610707703542174e0,
  P31 = -.0494730910623250734e0,
  P32 = -.226956593539686930e0,
  P33 = -.278661308609647788e0,
  P34 = -.0223192459734184686e0,
  Q30 = .0106209230528467918e0,
  Q31 = .191308926107829841e0,
  Q32 = 1.05167510706793207e0,
  Q33 = 1.98733201817135256e0,
  Q34 = 1.0e0;

  if (*objzgdk0 < -ULIMIT) {
    *lfu2qhid = 2.753624e-89;
    return;
  }
  if (*objzgdk0 >  ULIMIT) {
    *lfu2qhid = 1.0e0;
    return;
  }

  y = *objzgdk0 / SQRT2;
  if (y < 0.0e0) {
    y = -y;
    sn = -1;
  } else {
    sn = 1;
  }
  y2 = y * y;
  y4 = y2 * y2;
  y6 = y4 * y2;
  if (y < 0.46875e0) {
    R1 = P10 + P11 * y2 + P12 * y4 + P13 * y6;
    R2 = Q10 + Q11 * y2 + Q12 * y4 + Q13 * y6;
    erf = y * R1 / R2;
    *lfu2qhid = (sn == 1) ? 0.5e0 + 0.5 * erf : 0.5e0 - 0.5 * erf;
  } else
  if (y < 4.0e0) {
    y3 = y2 * y;
    y5 = y4 * y;
    y7 = y6 * y;
    R1 = P20 + P21 * y + P22 * y2 + P23 * y3 +
         P24 * y4 + P25 * y5 + P26 * y6 + P27 * y7;
    R2 = Q20 + Q21 * y + Q22 * y2 + Q23 * y3 +
         Q24 * y4 + Q25 * y5 + Q26 * y6 + Q27 * y7;
    erfc = exp(-y2) * R1 / R2;
    *lfu2qhid = (sn == 1) ? 1.0 - 0.5 * erfc : 0.5 * erfc;
  } else {
    z = y4;
    z2 = z * z;
    z3 = z2 * z;
    z4 = z2 * z2;
    R1 = P30 + P31 * z + P32 * z2 + P33 * z3 + P34 * z4;
    R2 = Q30 + Q31 * z + Q32 * z2 + Q33 * z3 + Q34 * z4;
    erfc = (exp(-y2)/y) * (1.0 / SQRTPI + R1 / (R2 * y2));
    *lfu2qhid = (sn == 1) ? 1.0 - 0.5 * erfc : 0.5 * erfc;
  }
}


void yiumjq3npnm1ow(double objzgdk0[], double lfu2qhid[], int *f8yswcat) {


  int    ayfnwr1v;

  for (ayfnwr1v = 0; ayfnwr1v < *f8yswcat; ayfnwr1v++) {
    yiumjq3npnm1or(objzgdk0++, lfu2qhid++);
  }
}


