library(knitr)
library(kableExtra)
library(testthat)

test_check("kableExtra")
