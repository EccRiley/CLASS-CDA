scales <-
function(..., iter=0, resid=FALSE, item.cor=FALSE, sort=FALSE, heat.map=FALSE)

  corCFA(..., iter=0, resid=FALSE, item.cor=FALSE, sort=FALSE,
              heat.map=FALSE, fun.call=match.call())

