cfa <-
function(...)

  corCFA(fun.call=match.call(), ...)

