bx <-
function(...)

  BoxPlot(fun.call=match.call(), ...)

