prop <-
function(...)

  corProp(...)

