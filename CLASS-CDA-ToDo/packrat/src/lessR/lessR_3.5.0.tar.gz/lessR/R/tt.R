tt <-
function(...)

  ttest(...)
