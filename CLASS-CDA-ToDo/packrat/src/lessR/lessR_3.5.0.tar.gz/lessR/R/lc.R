lc <-
function(...)

  LineChart(...)

