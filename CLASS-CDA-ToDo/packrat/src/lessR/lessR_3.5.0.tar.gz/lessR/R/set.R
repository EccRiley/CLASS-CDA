set <-
function(...) {

  message("New name for the set function:  theme\n")
  theme(...)

}

