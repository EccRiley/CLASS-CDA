tt.brief <-
function(..., brief=TRUE)

 ttest(..., brief=TRUE)

