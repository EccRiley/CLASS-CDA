reg <-
function(...)

  Regression(fun.call=match.call(), ...)
