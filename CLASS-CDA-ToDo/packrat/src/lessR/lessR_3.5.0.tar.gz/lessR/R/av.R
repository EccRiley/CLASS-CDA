av <-
function(...)

  ANOVA(...)

