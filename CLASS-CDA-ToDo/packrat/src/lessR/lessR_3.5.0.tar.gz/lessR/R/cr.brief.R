cr.brief <-
function(..., brief=TRUE)

cr(..., brief=TRUE)
