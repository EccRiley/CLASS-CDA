rd <-
function(...)

  Read(..., fun.call=match.call())

