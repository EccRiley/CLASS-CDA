wrt <-
function(...)

  Write(...)

