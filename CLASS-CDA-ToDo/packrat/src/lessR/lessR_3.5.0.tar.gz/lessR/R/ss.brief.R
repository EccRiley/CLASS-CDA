ss.brief <-
function(..., brief=TRUE)

  SummaryStats(..., brief=TRUE)
