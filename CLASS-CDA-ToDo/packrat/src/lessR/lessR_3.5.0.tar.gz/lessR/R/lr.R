lr <-
function(...)

  Logit(...)

