ScatterPlot <-
function(...) {

  Plot(fun.call=match.call(), ...)

}
