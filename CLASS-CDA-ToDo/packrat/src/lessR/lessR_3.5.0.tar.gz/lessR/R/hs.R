hs <-
function(...)

  Histogram(fun.call=match.call(), ...)

