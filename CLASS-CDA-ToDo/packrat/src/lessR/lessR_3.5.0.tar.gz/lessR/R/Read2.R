Read2 <- 
function(..., sep=";", dec=",") 
         
  Read(..., fun.call=match.call(), sep=";", dec=",")
