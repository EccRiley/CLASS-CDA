ttp  <-
function(...) {

  ttestPower(...)

}
