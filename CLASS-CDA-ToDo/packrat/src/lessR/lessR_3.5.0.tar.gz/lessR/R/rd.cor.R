rd.cor <-
function(...)

  corRead(...)

