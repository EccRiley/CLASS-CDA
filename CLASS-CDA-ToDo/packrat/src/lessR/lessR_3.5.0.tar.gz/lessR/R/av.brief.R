av.brief <-
function(..., brief=TRUE)

  ANOVA(..., brief=TRUE)

