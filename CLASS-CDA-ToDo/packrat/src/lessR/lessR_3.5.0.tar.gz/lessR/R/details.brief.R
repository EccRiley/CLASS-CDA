details.brief <-
function(..., brief=TRUE)

 details(..., brief=TRUE)

