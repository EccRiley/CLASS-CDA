reg.brief <-
function(..., brief=TRUE)

  Regression(..., fun.call=match.call(), brief=TRUE)
