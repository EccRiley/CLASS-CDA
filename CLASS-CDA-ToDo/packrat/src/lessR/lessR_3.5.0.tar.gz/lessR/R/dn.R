dn <-
function(...)

  Density(fun.call=match.call(), ...)



