scree <-
function(...)

  corScree(...)

