model.brief <-
function(..., brief=TRUE)

  Model(..., brief=TRUE)
