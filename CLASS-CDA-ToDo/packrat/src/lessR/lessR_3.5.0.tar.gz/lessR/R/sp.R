sp <-
function(...) {

  Plot(fun.call=match.call(), ...)

}
