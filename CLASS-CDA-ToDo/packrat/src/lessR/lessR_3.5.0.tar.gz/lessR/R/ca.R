ca <-
function(...)

  CountAll(...)

