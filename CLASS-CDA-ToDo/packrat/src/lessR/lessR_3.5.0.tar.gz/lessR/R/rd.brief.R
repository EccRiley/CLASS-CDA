rd.brief <-
function(..., brief=TRUE)

 Read(..., fun.call=match.call(), brief=TRUE)

