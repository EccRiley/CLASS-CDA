print.out_piece <- function(x, ...) {

    for (i in 1:length(x)) cat(x[i], "\n")

}

